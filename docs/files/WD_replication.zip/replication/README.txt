Replication Notes for: "The Political Behavior of Family Firms: Evidence From Brazil"


Scripts and Functions:
replication.Rproj - RStudio Project file. We recommend to start here
analysis.R - Code for the replication of all tables and figures
utils.R - Functions called by analysis.R. You will need to install all the packages listed at
the beggining of utils.R

Datasets:
data/candidates_relevant.csv - List of individuals in the leadership of the firms in the sample who were candidates in each election cycle considered (Source: TSE)
data/coalitions.csv - Parties in the government coalition at the time of each election cycle (Source: Wikipedia)
data/contributions_relevant_not_grouped.csv - Contributions by firms or individuals in our sample (Source: TSE)
data/data_ipo.csv - Data on IPOs in Latin America (see the Online Appendix for the sources)
data/firms_labels.csv - Labels for the variables in firms_merged.csv
data/firms_merged.csv - Dataset of firms in our sample (Source: CVM)
data/individuals_labels.csv - Labels for the variables in individuals_merged.csv 
data/individuals_merged.csv - Data on individuals in the firms in our sample (Source: CVM)
data/non_automatic.xlsx - Data on non-automatic BNDES loans (Source: BNDES)
data/participation_clean.csv - Data on firms controlled by the firms in our sample (Source: CVM)
data/petopost.csv - Data from the World Management Survey, from Bloom, Nicholas, Rafaella Sadun and John Van Reenen. 2015. “Do Private Equity Owned Firms have Beer Management practices?” American Economic Review 105(5):442–46.
data/real_conversion.csv - Conversion rates from Brazilian Real to 2020 US Dollar
data/var_definitions.csv - Definitions of the variables in firms_merged.csv
