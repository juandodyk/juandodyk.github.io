source("utils.R")


######################################################################~
# Firms-level Results ####
######################################################################~

firms = import_csv("data/firms_merged.csv", encoding = "UTF-8")

firms_labels = import_csv("data/firms_labels.csv") %>%
  with(as.list(label) %>% set_names(variable))

controls_full = expr(assets_log + income_log + age_log +
                  foreign + state_owned)

cg_controls = expr(ordinary_shares_natural + ordinary_herfindahl +
                     ordinary_shares_free_float_direct +
                     has_preferential_shares + largest_shareholder_gap)

m1 = felm(contrib_total_bool ~ family_firm | year | 0 | cnpj,
          firms)

m2 = felm(contrib_total_bool ~ family_firm +
            !!cg_controls + !!controls_full | year + industry | 0 | cnpj,
          firms, keepX = TRUE)

m3 = felm(contrib_total_controlled_plus_bool ~ family_firm +
            !!cg_controls + !!controls_full | year + industry | 0 | cnpj,
          firms)

m4 = felm(contrib_total_controlled_all_bool ~ family_firm +
            !!cg_controls + !!controls_full | year + industry | 0 | cnpj,
          firms)

# Table A1: Family Firms and Campaign Contributions

list(m1, m2, m3, m4) %>%
  outreg(firms_labels,
         custom.header = list("Probability of Contribution by" = 1:4),
         custom.model.names =
           c("Firm", "Firm", "Firm + Subsidiaries", "Firm + Leadership") %>%
           add_model_numbers(),
         treatment = "family_firm",
         save = "TableA1")

# Figure 3: Family firms are more likely to contribute to politics

p = tibble(model = list(m1, m2, m3, m4),
       outcome = c(
         "Firm (No Controls)",
         "Firm",
         "Firm + Subsidiaries",
         "Firm + Leadership"
       ) %>% as_factor()) %>%
  mutate(model = map(model, function(m) {
    tibble(conf.level = c(0.9, 0.95)) %>%
      mutate(model = map(conf.level,
                         ~ tidy(m, conf.int = TRUE, conf.level = .))) %>%
      unnest(model)
    })) %>%
  unnest(model) %>%
  filter(term == "family_firm") %>%
  ggplot(aes(x = fct_rev(outcome), y = estimate,
             ymin = conf.low, ymax = conf.high)) +
  geom_pointrange() +
  geom_linerange(size = 1.1, data = . %>% filter(conf.level == 0.9)) +
  geom_hline(yintercept = 0, linetype = 2, colour = "grey60") +
  theme_bw() +
  coord_flip() +
  xlab("") +
  ylab("Probability of Contribution")

print(p); ggsave("figs/families_contribute_coefplot.pdf", width = 4, height = 2)

print_tikz(p, "figs/Figure3.tex",
           width = 4, height = 2, standAlone = TRUE)


######################################################################~
# Individual-level Results ####
######################################################################~

# Table A2: Private Contributions by Individuals

individuals <- import_csv("data/individuals_merged.csv", encoding="UTF-8")

individuals_labels = import_csv("data/individuals_labels.csv") %>%
  with(as.list(label) %>% set_names(variable))

m1 = felm(I(contrib_total > 0) ~
            has_tie_bool | cnpj_year | 0 | cpf + cnpj_year,
          individuals)

m2 = felm(I(contrib_total > 0) ~
            has_tie_bool + is_manager + is_manager:is_in_bod +
            shares_ordinary + public_sector + age_log |
            cnpj_year | 0 | cpf + cnpj_year,
          individuals)

m5 = felm(I(contrib_total > 0) ~
            has_tie_bool + num_ties_closure | cnpj_year | 0 | cpf + cnpj_year,
          individuals)

m6 = felm(I(contrib_total > 0) ~
            has_tie_bool + num_ties_closure + is_manager +
            is_manager:is_in_bod + shares_ordinary + public_sector + age_log |
            cnpj_year | 0 | cpf + cnpj_year,
          individuals)

list(m1, m2, m5, m6) %>%
  outreg(individuals_labels,
         custom.header = list(
           "Probability of Contribution" = 1:4
         ) %>% turn_multi_cell(),
         treatment = "has_tie_bool",
         save = "TableA2")


# Figure 4: Individuals with family ties are more likely to contribute to politics

p = tibble(
  reg = list(m1, m2, m5, m6) %>%
    map(function(m) {
      tibble(conf.level = c(0.9, 0.95)) %>%
        mutate(model = map(conf.level,
                           ~ tidy(m, conf.int = TRUE, conf.level = .))) %>%
        unnest(model)
    }),
  term_ = c(rep("has_tie_bool", 2), rep("num_ties_closure", 2)),
  label = c("Family Member (No Controls)", "Family Member",
            "Number of Ties (No Controls)", "Number of Ties") %>%
    as_factor()
) %>%
  mutate(reg = map2(reg, term_, ~ filter(.x, term == .y))) %>%
  unnest(reg) %>%
  ggplot(aes(x = fct_rev(label), y = estimate,
             ymin = conf.low, ymax = conf.high)) +
  geom_pointrange() +
  geom_linerange(size = 1.1, data = . %>% filter(conf.level == 0.9)) +
  geom_hline(yintercept = 0, linetype = 2, colour = "grey60") +
  theme_bw() +
  coord_flip(clip = "off") +
  xlab("") +
  ylab("Probability of Contribution") +
  theme(plot.margin = margin(0.1, 0.5, 0.1, 0, "cm"))

print(p)
ggsave(str_glue("figs/ind_contrib_nocontrols.pdf"),
       width = 3, height = 2)

print_tikz(p, "figs/Figure4.tex",
           width = 4, height = 2, standAlone = TRUE)


######################################################################~
# Additional Firm-level Results ####
######################################################################~

firms = import_csv("data/firms_merged.csv", encoding = "UTF-8")

firms_labels = import_csv("data/firms_labels.csv") %>%
  with(as.list(label) %>% set_names(variable))

# Table A1 (Online Appendix): Family Firms and Contribution Amounts
# (conditional on donating)

data_all = firms %>%
  select(contrib_total, contrib_total_controlled_plus,
         contrib_total_controlled_all, family_firm,
         ordinary_shares_natural, ordinary_herfindahl,
         ordinary_shares_free_float_direct,
         has_preferential_shares, largest_shareholder_gap,
         assets_log, income_log, age_log,
         foreign, state_owned, year, industry, cnpj)

data1 = data_all %>%
  select(!c(contrib_total_controlled_plus, contrib_total_controlled_all)) %>%
  drop_na()
seleq1 = glm(I(contrib_total>0) ~ family_firm +
               ordinary_shares_natural + ordinary_herfindahl +
               ordinary_shares_free_float_direct +
               has_preferential_shares + largest_shareholder_gap +
               assets_log + income_log + age_log +
               foreign + state_owned + factor(year) + industry,
             family = binomial(link="probit"),
             data = data1)
data1$IMR = dnorm(seleq1$linear.predictors)/pnorm(seleq1$linear.predictors)

m1 = felm(log(contrib_total) ~ family_firm +
            ordinary_shares_natural + ordinary_herfindahl +
            ordinary_shares_free_float_direct +
            has_preferential_shares + largest_shareholder_gap +
            assets_log + income_log +
            foreign + state_owned + IMR |
            year + industry | 0 | cnpj,
          data1 %>% filter(contrib_total>0))

data2 = data_all %>%
  select(!c(contrib_total, contrib_total_controlled_all)) %>%
  drop_na()
seleq2 = glm(I(contrib_total_controlled_plus>0) ~ family_firm +
               ordinary_shares_natural + ordinary_herfindahl +
               ordinary_shares_free_float_direct +
               has_preferential_shares + largest_shareholder_gap +
               assets_log + income_log + age_log +
               foreign + state_owned + factor(year) + industry,
             family = binomial(link="probit"),
             data = data2)
data2$IMR = dnorm(seleq2$linear.predictors)/pnorm(seleq2$linear.predictors)

m2 = felm(log(contrib_total_controlled_plus) ~ family_firm +
            ordinary_shares_natural + ordinary_herfindahl +
            ordinary_shares_free_float_direct +
            has_preferential_shares + largest_shareholder_gap +
            assets_log + income_log +
            foreign + state_owned + IMR |
            year + industry | 0 | cnpj,
          data2 %>% filter(contrib_total_controlled_plus>0))

data3 = data_all %>%
  select(!c(contrib_total, contrib_total_controlled_plus)) %>%
  drop_na()
seleq3 = glm(I(contrib_total_controlled_all>0) ~ family_firm +
               ordinary_shares_natural + ordinary_herfindahl +
               ordinary_shares_free_float_direct +
               has_preferential_shares + largest_shareholder_gap +
               assets_log + income_log + age_log +
               foreign + state_owned + factor(year) + industry,
             family = binomial(link="probit"),
             data = data3)
data3$IMR = dnorm(seleq3$linear.predictors)/pnorm(seleq3$linear.predictors)

m3 = felm(log(contrib_total_controlled_all) ~ family_firm +
            ordinary_shares_natural + ordinary_herfindahl +
            ordinary_shares_free_float_direct +
            has_preferential_shares + largest_shareholder_gap +
            assets_log + income_log +
            foreign + state_owned + IMR |
            year + industry | 0 | cnpj,
          data3 %>% filter(contrib_total_controlled_all>0))

list(m1, m2, m3) %>%
  outreg(firms_labels,
         custom.header = list("Contributions (log) by" = 1:3),
         custom.model.names =
           c("Firm", "Firm + Subsidiaries", "Firm + Leadership") %>%
           add_model_numbers(),
         treatment = "family_firm",
         save = "TableA1_OA")


# Table A2 (Online Appendix): Number of Family Ties and Campaign Contributions

controls_full = expr(assets_log + income_log + age_log +
                       foreign + state_owned)

cg_controls = expr(ordinary_shares_natural + ordinary_herfindahl +
                     ordinary_shares_free_float_direct +
                     has_preferential_shares + largest_shareholder_gap)

m1 = felm(I(contrib_total > 0) ~ family_firm + family_firm:n_ties | year | 0 | cnpj,
          firms)

m2 = felm(I(contrib_total > 0) ~ family_firm + family_firm:n_ties +
            !!cg_controls + !!controls_full | year + industry | 0 | cnpj,
          firms)

m3 = felm(I(contrib_total_controlled_plus > 0) ~ family_firm + family_firm:n_ties +
            !!cg_controls + !!controls_full | year + industry | 0 | cnpj,
          firms)

m4 = felm(I(contrib_total_controlled_all > 0) ~ family_firm + family_firm:n_ties +
            !!cg_controls + !!controls_full | year + industry | 0 | cnpj,
          firms)

list(m1, m2, m3, m4) %>%
  outreg(firms_labels,
         custom.header = list("Probability of Contribution by" = 1:4),
         custom.model.names =
           c("Firm", "Firm", "Firm + Subsidiaries", "Firm + Leadership") %>%
           add_model_numbers(),
         treatment = "family_firm",
         save = "TableA2_OA")


# Table A3 (Online Appendix): Private Contributions by Individuals in Family
# vs Non-Family Firms

m1 = felm(I(contrib_total_ind > 0) ~ family_firm | year | 0 | cnpj,
          firms)

m2 = felm(I(contrib_total_ind > 0) ~ family_firm +
            !!cg_controls + !!controls_full | year + industry | 0 | cnpj,
          firms)

m3 = felm(log(contrib_total_ind) ~ family_firm | year | 0 | cnpj,
          firms %>% filter(contrib_total_ind > 0))

m4 = felm(log(contrib_total_ind) ~ family_firm +
            !!cg_controls + !!controls_full | year + industry | 0 | cnpj,
          firms %>% filter(contrib_total_ind > 0))

list(m1, m2, m3, m4) %>% #screenreg()
  outreg(firms_labels,
         custom.header = list(
           "Contributions (Binary)" = 1:2,
           "\\begin{tabular}{@{}c@{}}Contributions (log)\\\\conditional on donating\\end{tabular}" = 3:4
         ),
         treatment = "family_firm",
         save = "TableA3_OA")

# Table A4 (Online Appendix): Family Firms and Campaign Contributions (excluding municipal elections)

m1 = felm(contrib_total_bool ~ family_firm | year | 0 | cnpj,
          firms %>% filter(year %% 4 != 0))

m2 = felm(contrib_total_bool ~ family_firm +
            !!cg_controls + !!controls_full | year + industry | 0 | cnpj,
          firms %>% filter(year %% 4 != 0))

m3 = felm(contrib_total_controlled_plus_bool ~ family_firm +
            !!cg_controls + !!controls_full | year + industry | 0 | cnpj,
          firms %>% filter(year %% 4 != 0))

m4 = felm(contrib_total_controlled_all_bool ~ family_firm +
            !!cg_controls + !!controls_full | year + industry | 0 | cnpj,
          firms %>% filter(year %% 4 != 0))

list(m1, m2, m3, m4) %>%
  outreg(firms_labels,
         custom.header = list("Contributions by" = 1:4),
         custom.model.names =
           c("Firm", "Firm", "Firm + Subsidiaries", "Firm + Leadership") %>%
           add_model_numbers(),
         treatment = "family_firm",
         save = "TableA4_OA")

# Figure A1 (Online Appendix): Heterogeneous effects of family firm status
# on probability of contribution, by industry

kIndustries = c("Agriculture", "Extractive", "Manufacturing", "Energy",
                "Utilities", "Construction", "Services", "Finance", "Holding",
                "Public Administration")

controls = expr(assets_log + income_log + age_log + foreign + state_owned)

p = tibble(model = list(
  felm(I(contrib_total_controlled_plus > 0) ~
         family_firm:industry + industry +
         !!cg_controls + !!controls | year | 0 | cnpj,
       firms)
)) %>%
  mutate(model = map(model, function(m) {
    tibble(conf.level = c(0.9, 0.95)) %>%
      mutate(model = map(conf.level,
                         ~ tidy(m, conf.int = TRUE, conf.level = .))) %>%
      unnest(model)
  })) %>%
  unnest(model) %>%
  filter(str_starts(term, "family")) %>%
  mutate(term = str_sub(term, str_length("family_firm:industry.")) %>%
           factor(kIndustries) %>%
           fct_rev() %>%
           fct_relabel(~ str_c("Family Firm $\\times$ ", .))) %>%
  ggplot(aes(x = term, y = estimate,
             ymin = conf.low, ymax = conf.high)) +
  geom_pointrange() +
  geom_linerange(size = 1.1, data = . %>% filter(conf.level == 0.9)) +
  geom_hline(yintercept = 0, linetype = 2, colour = "grey60") +
  coord_flip() +
  ylab("Probability of Contribution") +
  xlab("") +
  theme_bw()

print(p)
ggsave(str_glue("figs/families_contribute_coefplot_byindustry.pdf"),
       width = 4, height = 4)

print_tikz(p, "figs/FigureA1_OA.tex",
           width = 4.5, height = 4, standAlone = TRUE)


######################################################################~
# Persistence of Contributions ####
######################################################################~

firms = import_csv("data/firms_merged.csv", encoding = "UTF-8")
firms_labels = import_csv("data/firms_labels.csv") %>%
  with(as.list(label) %>% set_names(variable))

contributions = import_csv("data/contributions_relevant_not_grouped.csv")

contributions = contributions %>%
  left_join(
    import_csv("data/coalitions.csv") %>%
      mutate(parties = parties %>% map(str_split, ",") %>% map(1)) %>%
      rename(party_id = parties) %>%
      unnest(party_id) %>%
      distinct() %>%
      mutate(in_coalition = TRUE)
  ) %>%
  mutate(across(in_coalition, replace_na, FALSE))

contribs_firms = contributions %>%
  select(cnpj_root = CPFCNPJ_donor,
         year,
         cpf_cand = CPF_candidate,
         party = party_id,
         amount,
         date,
         in_coalition)
contribs_firms_controlled = contribs_firms %>%
  bind_rows(
    contribs_firms %>%
      inner_join(import_csv("data/participation_clean.csv",
                            encoding="UTF-8") %>%
                   filter(participation_has_control) %>%
                   mutate(cnpj_root = substr(participation_cnpj, 1, 8),
                          cnpj_owner_root = substr(cnpj, 1, 8)) %>%
                   select(cnpj_root, cnpj_owner_root, year),
                 by = c("cnpj_root", "year")) %>%
      mutate(cnpj_root = cnpj_owner_root) %>%
      select(!cnpj_owner_root)
  )
contribs_firms_controlled_ind = contribs_firms_controlled %>%
  left_join(import_csv("data/individuals_merged.csv", encoding="UTF-8") %>%
              select(cnpj_firm = cnpj, year, cnpj_root = cpf) %>%
              mutate(cnpj_firm = substr(cnpj_firm, 1, 8)),
            by = c("cnpj_root", "year")) %>%
  mutate(cnpj_root =
           ifelse(!is.na(cnpj_firm), cnpj_firm, cnpj_root)) %>%
  select(!cnpj_firm)
contribs_firms = contribs_firms %>%
  filter(cnpj_root %in% unique(firms$cnpj_root))
contribs_firms_controlled = contribs_firms_controlled %>%
  filter(cnpj_root %in% unique(firms$cnpj_root))
contribs_firms_controlled_ind = contribs_firms_controlled_ind %>%
  filter(cnpj_root %in% unique(firms$cnpj_root))


# Table 1: Overlap Across Election Cycles, by Firm Type

contribs_firms_ext = contribs_firms %>%
  distinct(cnpj_root, year, cpf_cand) %>%
  filter(cpf_cand != "")
contribs_firms_ext = contribs_firms_ext %>%
  mutate(contrib = TRUE) %>%
  full_join(contribs_firms_ext %>%
              mutate(year = year + 4,
                     contrib_lag = TRUE),
            by = c("cpf_cand", "year", "cnpj_root")) %>%
  mutate(across(c(contrib, contrib_lag), replace_na, FALSE)) %>%
  left_join(select(firms, cnpj_root, year, family_firm),
            by = c("cnpj_root", "year"))

contribs_firms_ext = contribs_firms_controlled_ind %>%
  distinct(cnpj_root, year, party)
contribs_firms_ext = contribs_firms_ext %>%
  mutate(contrib = TRUE) %>%
  full_join(contribs_firms_ext %>%
              mutate(year = year + 4,
                     contrib_lag = TRUE),
            by = c("party", "year", "cnpj_root")) %>%
  mutate(across(c(contrib, contrib_lag), replace_na, FALSE)) %>%
  left_join(select(firms, cnpj_root, year, family_firm),
            by = c("cnpj_root", "year"))
df = contribs_firms_ext %>%
  group_by(family_firm, party, year) %>%
  summarise(prop_contr_both = 100 * sum(contrib * contrib_lag) / n(),
            n = n()) %>%
  group_by(party) %>%
  mutate(n = sum(n)) %>%
  ungroup() %>%
  pivot_wider(names_from = family_firm, values_from = prop_contr_both) %>%
  group_by(year) %>%
  summarise(across(c(`0`, `1`),
                   list(
                     wm = ~ sum(. * n / sum(n), na.rm = TRUE),
                     mean = ~ mean(., na.rm = TRUE)
                   ))) %>%
  mutate(diff_wm = `1_wm` - `0_wm`,
         diff_m = `1_mean` - `0_mean`) %>%
  filter(between(year, 2010, 2018)) %>%
  select(Year = year,
         "Non-Family Firms (m)" = `0_mean`,
         "Family Firms (m)" = `1_mean`,
         "Difference (m)" = `diff_m`,
         "Non-Family Firms (wm)" = `0_wm`,
         "Family Firms (wm)" = `1_wm`,
         "Difference (wm)" = `diff_wm`) %>%
  mutate(Year = str_c(Year - 4, "-", Year),
         across(where(is.numeric), round, 2))

str_c(c(names(df) %>% {.[-1]} %>%
          add_model_numbers() %>%
          str_c("\\multicolumn{1}{c}{", ., "}") %>%
          str_c(collapse = " & "),
        str_c("\\midrule", pmap_chr(df, str_c, sep = " & "))),
      collapse = " \\\\\n") %>%
  str_remove_all("\\([a-z]+\\)") %>% # { cat(.); write_clip(.) }
  str_c("\\begin{threeparttable}
\\begin{tabular}{@{}c@{} D{.}{.}{2.2}@{}D{.}{.}{2.2}@{}D{.}{.}{2.2}@{}D{.}{.}{2.2}@{}D{.}{.}{2.2}@{}D{.}{.}{2.2}@{}} \\toprule
& \\multicolumn{3}{c}{Average} & \\multicolumn{3}{c}{Weighted Average} \\\\
\\cmidrule(lr){2-4} \\cmidrule(lr){5-7}\n & ",
        .,
        "\\\\\\bottomrule\\end{tabular}\\begin{tablenotes}[para] \\footnotesize \\textit{Notes}:
        \\end{tablenotes}\\end{threeparttable}") %>%
  save_latex_table("Table1")


contribs_firms_ext = contribs_firms_controlled_ind %>%
  distinct(cnpj_root, year, party)
contribs_firms_ext = contribs_firms_ext %>%
  mutate(contrib = TRUE) %>%
  full_join(contribs_firms_ext %>%
              mutate(year = year + 4,
                     contrib_lag = TRUE),
            by = c("party", "year", "cnpj_root")) %>%
  full_join(contribs_firms_ext %>%
              mutate(year = year + 8,
                     contrib_lag2 = TRUE),
            by = c("party", "year", "cnpj_root")) %>%
  mutate(across(c(contrib, contrib_lag, contrib_lag2), replace_na, FALSE))
contribs_firms_int = contribs_firms_controlled_ind %>%
  group_by(cnpj_root, year) %>%
  summarise(amount = sum(amount)) %>%
  ungroup()
contribs_firms_int = contribs_firms_int %>%
  full_join(
    contribs_firms_int %>%
      rename(amount_lag = amount) %>%
      mutate(year = year + 4)
  ) %>% full_join(
    contribs_firms_int %>%
      rename(amount_lag2 = amount) %>%
      mutate(year = year + 8)
  ) %>%
  mutate(across(c(amount, amount_lag, amount_lag2), replace_na, 0))

firms = import_csv("data/firms_merged.csv", encoding = "UTF-8")
firms = firms %>% left_join(
  contribs_firms_ext %>%
    group_by(cnpj_root, year) %>%
    summarise(contrib_n_parties_controlled_all_lag = sum(contrib_lag),
              contrib_n_parties_controlled_all_lag2 = sum(contrib_lag2),
              contrib_party_intersection_lag = sum(contrib * contrib_lag),
              contrib_party_intersection_lag2 = sum(contrib * contrib_lag2)),
  by = c("cnpj_root", "year")
) %>%
  mutate(across(c(contrib_n_parties_controlled_all_lag,
                  contrib_n_parties_controlled_all_lag2,
                  contrib_party_intersection_lag,
                  contrib_party_intersection_lag2),
                replace_na, 0))
firms = firms %>%
  left_join(
    contribs_firms_int %>%
      select(cnpj_root, year,
             contrib_total_controlled_all_lag = amount_lag,
             contrib_total_controlled_all_lag2 = amount_lag2)
  ) %>%
  mutate(across(starts_with("contrib_total_controlled_all_lag"),
                replace_na, 0))
firms = firms %>%
  left_join(
    firms %>%
      select(cnpj, year, starts_with("contrib_total")) %>%
      rename_with(str_c, .cols = starts_with("contrib_total"), "_leg") %>%
      mutate(year = year + 4)) %>%
  mutate(across(starts_with("contrib_total"), replace_na, 0))

m1 = lfe::felm(I(contrib_party_intersection_lag/contrib_n_parties_controlled_all_lag) ~
                 family_firm +
                 assets_log + income_log +
                 age_log + foreign + state_owned | industry + year | 0 | cnpj,
               firms %>% filter(contrib_n_parties_controlled_all_lag > 0),
               keepX = TRUE)

m2 = lfe::felm(I(contrib_party_intersection_lag/contrib_n_parties_controlled_all_lag) ~
                 family_firm + log(contrib_total_controlled_all_lag) +
                 assets_log + income_log + age_log + foreign + state_owned |
                 industry + year | 0 | cnpj,
               firms %>% filter(contrib_total_controlled_all_lag > 0),
               keepX = TRUE)

m3 = lfe::felm(I(contrib_party_intersection_lag2/contrib_n_parties_controlled_all_lag2) ~
                 family_firm +
                 assets_log + income_log +
                 age_log + foreign + state_owned | industry + year | 0 | cnpj,
               firms %>% filter(contrib_n_parties_controlled_all_lag2 > 0),
               keepX = TRUE)

m4 = lfe::felm(I(contrib_party_intersection_lag2/contrib_n_parties_controlled_all_lag2) ~
                 family_firm + log(contrib_total_controlled_all_lag) +
                 assets_log + income_log +
                 age_log + foreign + state_owned | industry + year | 0 | cnpj,
               firms %>% filter(contrib_n_parties_controlled_all_lag2 > 0) %>%
                 mutate(contrib_total_controlled_all_lag =
                          contrib_total_controlled_all_lag2),
               keepX = TRUE)


# Table B1 (Online Appendix): Overlap of Contributions Across Election Cycles

list(m1, m2, m3, m4) %>%
  outreg(firms_labels,
         custom.header = list(
           "Overlap (One Electoral Cycle)" = 1:2,
           "Overlap (Two Electoral Cycles)" = 3:4
         ),
         treatment = "family_firm",
         save = "TableB1_OA")

# Figure 5: Overlap of contributions across election cycles

p = tibble(model = list(m1, m3),
           outcome = c(
             "Across One Electoral Cycle",
             "Across Two Electoral Cycles"
           )) %>%
  mutate(model = map(model, function(m) {
    tibble(conf.level = c(0.9, 0.95)) %>%
      mutate(model = map(conf.level,
                         ~ tidy(m, conf.int = TRUE, conf.level = .))) %>%
      unnest(model)
  })) %>%
  unnest(model) %>%
  filter(term == "family_firm") %>%
  ggplot(aes(x = fct_rev(outcome), y = estimate,
             ymin = conf.low, ymax = conf.high)) +
  geom_pointrange() +
  geom_linerange(size = 1.1, data = . %>% filter(conf.level == 0.9)) +
  geom_hline(yintercept = 0, linetype = 2, colour = "grey60") +
  theme_bw() +
  coord_flip(clip = "off") +
  xlab("") +
  ylab("Difference in Overlap") +
  theme(plot.margin = margin(0.1, 0.5, 0.1, 0, "cm"))

print(p)
ggsave(str_glue("figs/overlap_coefs.pdf"),
       width = 4, height = 2)

print_tikz(p, "figs/Figure5.tex",
           width = 4, height = 2, standAlone = TRUE)


######################################################################~
# Loyalty to Specific Parties ####
######################################################################~

# To run this section of the code, run the previous one first

# Figure 6: Persistence of contributions by family firms to specific parties
# across one election cycle (4 years)

contrib_party_ext = contribs_firms_controlled_ind %>%
  mutate(party = dplyr::recode(party, PMDB = "MDB")) %>%
  filter(party %in% c("PT", "MDB", "PSDB", "DEM")) %>%
  group_by(cnpj_root, year, party) %>%
  summarise(across(amount, sum)) %>%
  ungroup() %>%
  pivot_wider(names_from = party, values_from = amount) %>%
  mutate(across(!c(cnpj_root, year), replace_na, 0))
contrib_party_ext = contrib_party_ext %>%
  full_join(
    contrib_party_ext %>%
      rename_with(str_c, !c(cnpj_root, year), "_lag") %>%
      mutate(year = year + 4)
  ) %>%
  full_join(
    contrib_party_ext %>%
      rename_with(str_c, !c(cnpj_root, year), "_lag2") %>%
      mutate(year = year + 8)
  ) %>%
  mutate(across(!c(cnpj_root, year), replace_na, 0))

firms = import_csv("data/firms_merged.csv", encoding = "UTF-8")
firms = firms %>% left_join(
  contrib_party_ext %>%
    rename_with(~ str_c("party_", .), !c(cnpj_root, year))
) %>%
  mutate(across(starts_with("party_"), replace_na, 0),
         across(matches("^party_[^_]+_lag$"),
                ~ ifelse(year - 4 < 2006, NA, .)),
         across(matches("^party_[^_]+_lag2$"),
                ~ ifelse(year - 8 < 2006, NA, .)))

m1 = felm(party ~ party_lag + party_lag*family_firm +
            assets_log + income_log +
            age_log + foreign + state_owned | industry + year | 0 | cnpj,
          firms %>%
            mutate(party = as.numeric(party_MDB > 0),
                   party_lag = as.numeric(party_MDB_lag > 0)))
m2 = felm(party ~ party_lag + party_lag*family_firm +
            assets_log + income_log +
            age_log + foreign + state_owned | industry + year | 0 | cnpj,
          firms %>%
            mutate(party = as.numeric(party_PT > 0),
                   party_lag = as.numeric(party_PT_lag > 0)))
m3 = felm(party ~ party_lag + party_lag*family_firm +
            assets_log + income_log +
            age_log + foreign + state_owned | industry + year | 0 | cnpj,
          firms %>%
            mutate(party = as.numeric(party_PSDB > 0),
                   party_lag = as.numeric(party_PSDB_lag > 0)))

m4 = felm(party ~ party_lag + party_lag*family_firm +
            assets_log + income_log +
            age_log + foreign + state_owned | industry + year | 0 | cnpj,
          firms %>%
            mutate(party = as.numeric(party_MDB > 0),
                   party_lag = as.numeric(party_MDB_lag2 > 0)))
m5 = felm(party ~ party_lag + party_lag*family_firm +
            assets_log + income_log +
            age_log + foreign + state_owned | industry + year | 0 | cnpj,
          firms %>%
            mutate(party = as.numeric(party_PT > 0),
                   party_lag = as.numeric(party_PT_lag2 > 0)))
m6 = felm(party ~ party_lag + party_lag*family_firm +
            assets_log + income_log +
            age_log + foreign + state_owned | industry + year | 0 | cnpj,
          firms %>%
            mutate(party = as.numeric(party_PSDB > 0),
                   party_lag = as.numeric(party_PSDB_lag2 > 0)))

m7 = felm(party ~ party_lag + party_lag*family_firm +
            assets_log + income_log +
            age_log + foreign + state_owned | industry + year | 0 | cnpj,
          firms %>%
            mutate(party = as.numeric(party_DEM > 0),
                   party_lag = as.numeric(party_DEM_lag2 > 0)))
m8 = felm(party ~ party_lag + party_lag*family_firm +
            assets_log + income_log +
            age_log + foreign + state_owned | industry + year | 0 | cnpj,
          firms %>%
            mutate(party = as.numeric(party_DEM > 0),
                   party_lag = as.numeric(party_DEM_lag2 > 0)))

p = tibble(
  model = list(m1, m2, m3, m4, m5, m6, m7, m8),
  outcome = rep(str_c("FF $\\times$ ", c("MDB", "PT", "PSDB", "DEM")), 2) %>%
    as_factor(),
  type = c(rep("One Election Cycle After", 4),
           rep("Two Election Cycles After", 4))
) %>%
  mutate(model = map(model, function(m) {
    tibble(conf.level = c(0.9, 0.95)) %>%
      mutate(model = map(conf.level,
                         ~ tidy(m, conf.int = TRUE, conf.level = .))) %>%
      unnest(model)
  })) %>%
  unnest(model) %>%
  filter(term == "party_lag:family_firm") %>%
  ggplot(aes(x = fct_rev(outcome), y = estimate,
             ymin = conf.low, ymax = conf.high)) +
  geom_pointrange() +
  geom_linerange(size = 1.1, data = . %>% filter(conf.level == 0.9)) +
  geom_hline(yintercept = 0, linetype = 2, colour = "grey60") +
  theme_bw() +
  coord_flip() +
  xlab("") +
  ylab("Probability of Contribution") +
  facet_wrap(~ type)

print(p)
ggsave(str_glue("figs/party_loyalty.pdf"), width = 5, height = 2)

print_tikz(p, "figs/Figure6.tex", width = 5, height = 2, standAlone = TRUE)


# Table B2 (Online Appendix): Loyalty of Contributions to Specific Parties

list(m1, m2, m3, m4, m5, m6, m7, m8) %>%
  outreg(firms_labels,
         custom.model.names =
           c("MDB", "PT", "PSDB", "DEM", "MDB", "PT", "PSDB", "DEM") %>%
           add_model_numbers(),
         custom.header = list(
           "Probability of Contribution to#(One Election Cycle After)" = 1:4,
           "Probability of Contribution to#(Two Election Cycles After)" = 5:8
         ) %>%
           set_names(names(.) %>% map_chr(multi_cell, sep = "#")),
         treatment = c("party_lag", "family_firm"),
         save = "TableB2_OA")


######################################################################~
# Campaign Contributions and State-Subsidized Loans ####
######################################################################~

firms = import_csv("data/firms_merged.csv", encoding = "UTF-8")
firms_labels = import_csv("data/firms_labels.csv") %>%
  with(as.list(label) %>% set_names(variable))

controlled = import_csv("data/participation_clean.csv", encoding="UTF-8") %>%
  filter(participation_has_control) %>%
  mutate(cnpj_root = substr(participation_cnpj, 1, 8))

loans = read_excel("data/non_automatic.xlsx", skip = 3) %>%
  mutate(cnpj_root = substr(CNPJ, 1, 8)) %>%
  filter(cnpj_root %in% unique(c(firms$cnpj_root, controlled$cnpj_root))) %>%
  mutate(year = map_chr(str_split(`Data da contratação`, '-'), 1),
         year = as.integer(year),
         value = `Valor contratado  R$`) %>%
  left_join(import_csv("data/real_conversion.csv"), by = "year") %>%
  mutate(value = value * conversion)

not_automatic = loans %>%
  group_by(cnpj_root, year) %>%
  summarise(n_loans = n(), value = sum(value))

controlled = controlled %>%
  left_join(not_automatic, by = c("cnpj_root", "year")) %>%
  mutate(across(c(n_loans, value), ~ ifelse(is.na(.), 0, .))) %>%
  group_by(cnpj, year) %>%
  summarise(n_loans_controlled = sum(n_loans),
            value_controlled = sum(value)) %>%
  mutate(cnpj_root = substr(cnpj, 1, 8))

loans_post = expand_grid(cnpj_root = unique(firms$cnpj_root),
                         year = seq(2009, 2020)) %>%
  left_join(not_automatic, by = c("cnpj_root", "year")) %>%
  left_join(controlled, by = c("cnpj_root", "year")) %>%
  mutate(across(c(n_loans, value, n_loans_controlled, value_controlled),
                ~ ifelse(is.na(.), 0, .)),
         year = 2010 + 2 * ((year - 2011) %/% 2)) %>%
  filter(year >= 2010) %>%
  group_by(cnpj_root, year) %>%
  summarise(across(c(n_loans, value, n_loans_controlled, value_controlled),
                   sum)) %>%
  mutate(n_loans_all = n_loans + n_loans_controlled,
         value_all = value + value_controlled)

loans_pre = expand_grid(cnpj_root = unique(firms$cnpj_root),
                        year = seq(2010-4, 2018)) %>%
  left_join(not_automatic, by = c("cnpj_root", "year")) %>%
  left_join(controlled, by = c("cnpj_root", "year")) %>%
  mutate(across(c(n_loans, value, n_loans_controlled, value_controlled),
                ~ ifelse(is.na(.), 0, .)),
         year = 2010 + 4 * ((year - 2007) %/% 4)) %>%
  filter(year <= 2018) %>%
  group_by(cnpj_root, year) %>%
  summarise(across(c(n_loans, value, n_loans_controlled, value_controlled),
                   sum)) %>%
  mutate(n_loans_all = n_loans + n_loans_controlled,
         value_all = value + value_controlled)

firms = import_csv("data/firms_merged.csv", encoding = "UTF-8") %>%
  left_join(loans_post, by = c("cnpj_root", "year")) %>%
  left_join(firms %>%
              select(cnpj, year, assets_log_lag = assets_log,
                     income_log_lag = income_log) %>%
              mutate(year = year + 2),
            by = c("cnpj", "year"))

m1 = felm(I(n_loans>0) ~ contrib_total_bool + assets_log + income_log +
            age_log + state_owned | year + industry | 0 | cnpj,
          firms %>% filter(year %in% c(2010, 2014)),
          keepX = TRUE)

m2 = felm(I(n_loans>0) ~ contrib_total_bool * family_firm +
            assets_log + income_log + age_log +
            state_owned | year + industry | 0 | cnpj,
          firms %>% filter(year %in% c(2010, 2014)),
          keepX = TRUE)

m3 = felm(log(value+1) ~ contrib_total_bool + assets_log + income_log +
            age_log + state_owned | year + industry | 0 | cnpj,
          firms %>% filter(year %in% c(2010, 2014)))#, value>0))

m4 = felm(log(value+1) ~ contrib_total_bool * family_firm +
            assets_log + income_log + age_log + state_owned |
            year + industry | 0 | cnpj,
          firms %>% filter(year %in% c(2010, 2014)))#, value>0))

data = firms %>% filter(year %in% c(2010, 2014)) %>%
  select(n_loans, contrib_total_bool, family_firm,
         assets_log, income_log, age_log,
         state_owned, year, industry, value, cnpj,
         contrib_total) %>%
  mutate(contrib_total = log(contrib_total + 1)) %>%
  drop_na()

seleq3 = glm(I(n_loans>0) ~ contrib_total_bool * family_firm +
               assets_log + income_log + age_log +
               state_owned + factor(year) + factor(industry),
             family = binomial(link="probit"),
             data = data)
data$IMR = dnorm(seleq3$linear.predictors)/pnorm(seleq3$linear.predictors)
m3 = felm(log(value) ~ contrib_total_bool +
            assets_log + income_log + state_owned + IMR |
            year + industry | 0 | cnpj,
          data %>% filter(value>0))

seleq4 = glm(I(n_loans>0) ~ contrib_total_bool * family_firm +
               assets_log + income_log + age_log +
               state_owned + factor(year) + factor(industry),
             family = binomial(link="probit"),
             data = data)
data$IMR = dnorm(seleq4$linear.predictors)/pnorm(seleq4$linear.predictors)
m4 = felm(log(value) ~ contrib_total_bool * family_firm +
            assets_log + income_log + state_owned + IMR |
            year + industry | 0 | cnpj,
          data %>% filter(value>0))

seleq5 = glm(I(n_loans>0) ~ contrib_total * family_firm +
               assets_log + income_log + age_log +
               state_owned + factor(year) + factor(industry),
             family = binomial(link="probit"),
             data = data)
data$IMR = dnorm(seleq5$linear.predictors)/pnorm(seleq5$linear.predictors)
m5 = felm(log(value) ~ contrib_total +
            assets_log + income_log + state_owned + IMR |
            year + industry | 0 | cnpj,
          data %>% filter(value>0))

seleq6 = glm(I(n_loans>0) ~ contrib_total * family_firm +
               assets_log + income_log + age_log +
               state_owned + factor(year) + factor(industry),
             family = binomial(link="probit"),
             data = data)
data$IMR = dnorm(seleq6$linear.predictors)/pnorm(seleq6$linear.predictors)
m6 = felm(log(value) ~ contrib_total * family_firm +
            assets_log + income_log + state_owned + IMR |
            year + industry | 0 | cnpj,
          data %>% filter(value>0))

# Table C1 (Online Appendix): Campaign Contributions and BNDES Loans

list(m1, m2, m5, m6) %>%
  outreg(list(
    contrib_total_bool = "Contributed",
    `contrib_total_bool:family_firm` = "\\ $\\times$ Family Firm",
    contrib_total = "Contribution Size (log)",
    `contrib_total:family_firm` = "\\ $\\times$ Family Firm "
  ) %>%
    list_modify(!!!firms_labels) %>%
    list_modify(contrib_total = "Size of Contribution (log)"),
  custom.header = list(
    "Probability of Loan" = 1:2,
    "Loan Size (log)" = 3:4
  ) %>% turn_multi_cell(),
  treatment = c("contrib_total_bool", "family_firm"),
  save = "TableC1_OA")

df = m2 %>%
  tidy(conf.int = TRUE) %>%
  inner_join(tibble(
    term = c("contrib_total_bool", "family_firm",
             "contrib_total_bool:family_firm"),
    label = c("Contributed", "Family Firm", "FF x Contributed") %>%
      as_factor(),
    outcome = "Probability of Receiving BNDES Loan"
  ))

model_receive = m2

firms = import_csv("data/firms_merged.csv", encoding = "UTF-8") %>%
  left_join(loans_pre, by = c("cnpj_root", "year")) %>%
  mutate(n_loans_bool = as.numeric(n_loans > 0),
         debt_ratio = value/assets)

controls_full = expr(assets_log + income_log + age_log +
                       foreign + state_owned)

cg_controls = expr(ordinary_shares_natural + ordinary_herfindahl +
                     ordinary_shares_free_float_direct +
                     has_preferential_shares + largest_shareholder_gap)

m1 = felm(contrib_total_bool ~ family_firm * n_loans_bool | year | 0 | cnpj,
          firms)

m2 = felm(contrib_total_bool ~ family_firm * n_loans_bool +
            !!cg_controls + !!controls_full | year + industry | 0 | cnpj,
          firms)

m3 = felm(contrib_total_bool ~ family_firm * debt_ratio | year | 0 | cnpj,
          firms)

m4 = felm(contrib_total_bool ~ family_firm * debt_ratio +
            !!cg_controls + !!controls_full | year + industry | 0 | cnpj,
          firms)


# Table C2 (Online Appendix): BNDES Debt and Campaign Contributions

list(m1, m2, m3, m4) %>%
  outreg(firms_labels,
         custom.header = list("Probability of Contribution" = 1:4),
         treatment = c("family_firm", "n_loans_bool"),
         save = "TableC2_OA")

# Figure 7: State-Subsidized Loans and Campaign Contributions

model_donate = m2
p = tibble(model = list(model_receive, model_donate),
           outcome = c("Probability of Receiving BNDES Loan",
                       "Probability of Contribution")) %>%
  mutate(model = map(model, function(m) {
    tibble(conf.level = c(0.9, 0.95)) %>%
      mutate(model = map(conf.level,
                         ~ tidy(m, conf.int = TRUE, conf.level = .))) %>%
      unnest(model)
  })) %>%
  unnest(model) %>%
  inner_join(tibble(
    term = c("contrib_total_bool", "family_firm",
             "contrib_total_bool:family_firm",
             "n_loans_bool", "family_firm",
             "family_firm:n_loans_bool"),
    label = c("Contributed", "Family Firm", "FF $\\times$ Contributed",
              "BNDES Debt", "Family Firm", "FF $\\times$ BNDES Debt"),
    outcome = c(rep("Probability of Receiving BNDES Loan", 3),
                rep("Probability of Contribution", 3))
  ) %>%
    mutate(label = factor(paste(label, outcome, sep = "__"),
                          levels = rev(paste(label, outcome, sep = "__"))))
  ) %>%
  ggplot(aes(x = label, y = estimate,
             ymin = conf.low, ymax = conf.high)) +
  geom_pointrange() +
  geom_linerange(size = 1.1, data = . %>% filter(conf.level == 0.9)) +
  geom_hline(yintercept = 0, linetype = 2, colour = "grey60") +
  theme_bw() +
  scale_x_discrete(labels = function(x) gsub("__.+$", "", x)) +
  coord_flip() +
  xlab("") +
  ylab("") +
  facet_wrap(~ as_factor(outcome), scales = "free")

print(p)
ggsave(str_glue("figs/bndes_feedback.pdf"),
       width = 7.5, height = 2)

print_tikz(p, "figs/Figure7.tex",
           width = 7.5, height = 2, standAlone = TRUE)


######################################################################~
# Contribution Targets ####
######################################################################~

# Add "%>% filter(year < 2016)" to produce results just for PT presidencies
firms = import_csv("data/firms_merged.csv", encoding = "UTF-8")

firms_labels = import_csv("data/firms_labels.csv") %>%
  with(as.list(label) %>% set_names(variable))

family_firm_sectors = expr(family_firm + industry)

controls = expr(assets_log + income_log + age_log)

ols_pt = felm(I(contrib_pt_controlled_all/contrib_total_controlled_all) ~
                !!family_firm_sectors + assets_log + age_log | year | 0 | cnpj,
              firms %>% filter(!foreign, !state_owned, contrib_total_controlled_all>0))

m_pt = selection(I(contrib_total_controlled_all>0) ~
                   !!family_firm_sectors + !!controls + as.factor(year),
                 I(contrib_pt_controlled_all/contrib_total_controlled_all) ~
                   !!family_firm_sectors + assets_log + age_log + as.factor(year),
                 firms %>% filter(!foreign, !state_owned),
                 method = "2step")

ols_pmdb = felm(I(contrib_mdb_controlled_all/contrib_total_controlled_all) ~
                  !!family_firm_sectors + assets_log + age_log | year | 0 | cnpj,
                firms %>% filter(!foreign, !state_owned, contrib_total_controlled_all>0))

m_pmdb = selection(I(contrib_total_controlled_all>0) ~
                     !!family_firm_sectors + !!controls + as.factor(year),
                   I(contrib_mdb_controlled_all/contrib_total_controlled_all) ~
                     !!family_firm_sectors + assets_log + age_log + as.factor(year),
                   firms %>% filter(!foreign, !state_owned),
                   method = "2step")

ols_psdb = felm(I(contrib_psdb_controlled_all/contrib_total_controlled_all) ~
                  !!family_firm_sectors + assets_log + age_log | year | 0 | cnpj,
                firms %>% filter(!foreign, !state_owned, contrib_total_controlled_all>0))

m_psdb = selection(I(contrib_total_controlled_all>0) ~
                     !!family_firm_sectors + !!controls + as.factor(year),
                   I(contrib_psdb_controlled_all/contrib_total_controlled_all) ~
                     !!family_firm_sectors + assets_log + age_log + as.factor(year),
                   firms %>% filter(!foreign, !state_owned),
                   method = "2step")

ols_dem = felm(I(contrib_dem_controlled_all/contrib_total_controlled_all) ~
                  !!family_firm_sectors + assets_log + age_log | year | 0 | cnpj,
                firms %>% filter(!foreign, !state_owned, contrib_total_controlled_all>0))

m_dem = selection(I(contrib_total_controlled_all>0) ~
                     !!family_firm_sectors + !!controls + as.factor(year),
                   I(contrib_dem_controlled_all/contrib_total_controlled_all) ~
                     !!family_firm_sectors + assets_log + age_log + as.factor(year),
                   firms %>% filter(!foreign, !state_owned),
                   method = "2step")

ols_party = felm(I(contrib_par_controlled_all/contrib_total_controlled_all) ~
                   !!family_firm_sectors + assets_log + age_log | year | 0 | cnpj,
                 firms %>% filter(!foreign, !state_owned, contrib_total_controlled_all>0))

m_party = selection(I(contrib_total_controlled_all>0) ~
                      !!family_firm_sectors + !!controls + as.factor(year),
                    I(contrib_par_controlled_all/contrib_total_controlled_all) ~
                      !!family_firm_sectors + assets_log + age_log + as.factor(year),
                    firms %>% filter(!foreign, !state_owned),
                    method = "2step")

ols_incumbent = felm(I(contrib_incumbent_controlled_all/contrib_total_controlled_all) ~
                       !!family_firm_sectors + assets_log + age_log | year | 0 | cnpj,
                     firms %>% filter(!foreign, !state_owned, contrib_total_controlled_all>0))

m_incumbent = selection(I(contrib_total_controlled_all>0) ~
                          !!family_firm_sectors + !!controls + as.factor(year),
                        I(contrib_incumbent_controlled_all/contrib_total_controlled_all) ~
                          !!family_firm_sectors + assets_log + age_log + as.factor(year),
                        firms %>% filter(!foreign, !state_owned),
                        method = "2step")

ols_insider = felm(I(contrib_insider_controlled_all/contrib_total_controlled_all) ~
                     !!family_firm_sectors + assets_log + age_log | year | 0 | cnpj,
                   firms %>% filter(!foreign, !state_owned, contrib_total_controlled_all>0))

m_insider = selection(I(contrib_total_controlled_all>0) ~
                        !!family_firm_sectors + !!controls + as.factor(year),
                      I(contrib_insider_controlled_all/contrib_total_controlled_all) ~
                        !!family_firm_sectors + assets_log + age_log + as.factor(year),
                      firms %>% filter(!foreign, !state_owned),
                      method = "2step")

ols_business = felm(I(contrib_business_controlled_all/contrib_total_controlled_all) ~
                      !!family_firm_sectors + assets_log + age_log | year | 0 | cnpj,
                    firms %>% filter(!foreign, !state_owned, contrib_total_controlled_all>0))

m_business = selection(I(contrib_total_controlled_all>0) ~
                         !!family_firm_sectors + !!controls + as.factor(year),
                       I(contrib_business_controlled_all/contrib_total_controlled_all) ~
                         !!family_firm_sectors + assets_log + age_log + as.factor(year),
                       firms %>% filter(!foreign, !state_owned),
                       method = "2step")

ols_num_parties = felm(contrib_n_parties_controlled_all ~
                         !!family_firm_sectors + assets_log + age_log | year | 0 | cnpj,
                       firms %>% filter(!foreign, !state_owned, contrib_total_controlled_all>0))

m_num_parties = selection(I(contrib_total_controlled_all>0) ~
                            !!family_firm_sectors + !!controls + as.factor(year),
                          contrib_n_parties_controlled_all ~
                            !!family_firm_sectors + assets_log + age_log + as.factor(year),
                          firms %>% filter(!foreign, !state_owned))

outcomes = c("Parties", "Incumbents", "PT", "MDB", "PSDB", "DEM",
             "Career Politician/Bureaucrat", "Business Candidates")

ols_summaries =
  list(ols_party, ols_incumbent, ols_pt, ols_pmdb, ols_psdb, ols_dem, ols_insider, ols_business) %>%
  map_dfr(~ summary(.)$coefficients["family_firm",]) %>%
  rename(`Std. Error` = `Cluster s.e.`) %>%
  mutate(outcome = outcomes,
         method = "OLS")


# Figure 8: Contribution Targets

p = tibble(
  model = list(m_party, m_incumbent, m_pt, m_pmdb,
               m_psdb, m_dem, m_insider, m_business,
               ols_party, ols_incumbent, ols_pt, ols_pmdb,
               ols_psdb, ols_dem, ols_insider, ols_business),
  outcome = rep(outcomes, 2),
  method = c(rep("Heckman", length(outcomes)),
             rep("OLS", length(outcomes)))
) %>%
  mutate(model = map(model, function(m) {
    tibble(conf.level = c(0.9, 0.95)) %>%
      mutate(model = map(conf.level,
                         ~ tidy(m, conf.int = TRUE, conf.level = .))) %>%
      unnest(model)
  })) %>%
  unnest(model) %>%
  filter(term == "family_firm") %>%
  mutate(method = fct_rev(as_factor(method))) %>%
  ggplot(aes(x = fct_rev(as_factor(outcome)), y = estimate,
             ymin = conf.low, ymax = conf.high)) +
  facet_wrap(~ method) +
  geom_pointrange() +
  geom_linerange(size = 1.1, data = . %>% filter(conf.level == 0.9)) +
  geom_hline(yintercept = 0, linetype = 2, colour = "grey60") +
  theme_bw() +
  coord_flip() +
  xlab("") +
  ylab("Share of Contributions by Family Firms")

print(p)
ggsave(str_glue("figs/heckmans_coefplot.pdf"),
       width = 5, height = 3)

print_tikz(p, "figs/Figure8.tex",
           width = 5, height = 3, standAlone = TRUE)

# Table D1 (Online Appendix): Contribution Targets (OLS)

list(ols_party, ols_incumbent, ols_pt, ols_pmdb, ols_psdb, ols_dem, ols_insider, ols_business) %>%
  outreg(firms_labels,
         custom.header = as.list(1:length(outcomes)) %>%
           set_names(outcomes %>% map_chr(multi_cell, sep = " ")),
         treatment = "family_firm",
         save = "TableD1_OA")

# Table D2 (Online Appendix): Contribution Targets (Heckman)

list(m_party, m_incumbent, m_pt, m_pmdb, m_psdb, m_dem, m_insider, m_business) %>%
  outreg(firms_labels,
         custom.header = as.list(1:length(outcomes)) %>%
           set_names(outcomes %>% map_chr(multi_cell, sep = " ")),
         treatment = "family_firm", fe = c("Year", "Industry"),
         save = "TableD2_OA")


######################################################################~
# Number of Parties ####
######################################################################~

# Figure 9: Number of Parties

firms = import_csv("data/firms_merged.csv", encoding = "UTF-8")
firms_labels = import_csv("data/firms_labels.csv") %>%
  with(as.list(label) %>% set_names(variable))

controls = expr(assets_log + income_log + age_log)

m1 = felm(contrib_n_parties_controlled_all ~
            family_firm + !!controls + foreign + state_owned |
            industry + year | 0 | cnpj,
          firms %>% filter(contrib_total_controlled_all>0))

m2 = selection(eval_formula(I(contrib_total_controlled_all>0) ~
                              family_firm + industry + !!controls + foreign +
                              state_owned + factor(year)),
               eval_formula(contrib_n_parties_controlled_all ~
                              family_firm + industry + assets_log + age_log +
                              foreign + state_owned + factor(year)),
               firms,
               method = "2step")

m3 = felm(contrib_n_eff_parties_controlled_all ~
            family_firm + !!controls + foreign + state_owned |
            industry + year | 0 | cnpj,
          firms %>% filter(contrib_total_controlled_all>0))

m4 = selection(eval_formula(I(contrib_n_eff_parties_controlled_all>0) ~
                              family_firm + industry + !!controls + foreign +
                              state_owned + factor(year)),
               eval_formula(contrib_n_eff_parties_controlled_all ~
                              family_firm + industry + assets_log + age_log +
                              foreign + state_owned + factor(year)),
               firms,
               method = "2step")

p = tibble(model = list(m1, m2, m3, m4),
           outcome = c(rep("Number of Parties", 2),
                       rep("Effective Number of Parties", 2)) %>% as_factor(),
           method = c("OLS", "Heckman", "OLS", "Heckman") %>% as_factor()) %>%
  mutate(model = map(model, function(m) {
    tibble(conf.level = c(0.9, 0.95)) %>%
      mutate(model = map(conf.level,
                         ~ tidy(m, conf.int = TRUE, conf.level = .))) %>%
      unnest(model)
  })) %>%
  unnest(model) %>%
  filter(term == "family_firm") %>%
  ggplot(aes(x = fct_rev(method), y = estimate,
             ymin = conf.low, ymax = conf.high)) +
  geom_pointrange() +
  geom_linerange(size = 1.1, data = . %>% filter(conf.level == 0.9)) +
  geom_hline(yintercept = 0, linetype = 2, colour = "grey60") +
  theme_bw() +
  coord_flip() +
  xlab("") +
  ylab("Number of Parties to Which the Firm Contributes") +
  facet_wrap(~outcome, scales = "free_x")

print(p)
ggsave(str_glue("figs/num_of_parties.pdf"),
       width = 6, height = 2)

print_tikz(p, "figs/Figure9.tex",
           width = 6, height = 2, standAlone = TRUE)


# Table E1 (Online Appendix): Family Firms and Number of Parties

list(m1, m2, m3, m4) %>%
  outreg(firms_labels,
         custom.header = list(
           "Number of parties" = 1:2,
           "Effective number of parties" = 3:4
         ),
         custom.model.names =
           c("OLS", "Heckman", "OLS", "Heckman") %>%
           add_model_numbers(),
         treatment = "family_firm", fe = c("Year", "Industry"),
         save = "TableE1_OA")


######################################################################~
# Institutional Ownership and Family Ties ####
######################################################################~

# Table G1 (Online Appendix): Institutional Ownership and Family Ties (Latin America)

data_ipo = read.csv("data/data_ipo.csv") %>%
  filter(!is.na(Year_establishment), !is.na(Largest_Shareholder_Post)) %>%
  mutate(PE_dummy = PE.Firm..if.any. != 0,
         age = Year - Year_establishment,
         inst_pre = PE_pre.IPO + MNC_pre.IPO + SOE_pre.IPO,
         ln_Sales_USD = log(Sales_USD + 1),
         ln_Assets_USD = log(Assets_USD + 1))

data_ipo_ = data_ipo %>%
  mutate(inst_pre = inst_pre / 100,
         Country = fct_relevel(Country, "BRA"))

fit1 <- felm(Family_Board ~  age +  ln_Assets_USD  +
               Finance +
               Infraestructure + inst_pre + SOE_pre.IPO |
               Year + Country | 0 | Company_name,
             data = data_ipo_)

fit2 <- felm(Family_Board ~  age + ln_Assets_USD  +
               Finance + Infraestructure + inst_pre * factor(Country) +
               SOE_pre.IPO | Year | 0 | Company_name,
             data = data_ipo_)

fit3 <- felm(Family_Board ~  age + ln_Assets_USD  +
               Finance + Infraestructure + inst_pre + SOE_pre.IPO |
               Year + Country | 0 | Company_name,
             data = data_ipo_ %>% filter(Country != "BRA"))

list(fit1, fit2, fit3) %>%
  outreg(list(
    inst_pre = "Institutional Ownership (%) Pre-IPO",
    "inst_pre:factor(Country)ARG" = "\\ $\\times$ Argentina",
    "inst_pre:factor(Country)CHI" = "\\ $\\times$ Chile",
    "inst_pre:factor(Country)COL" = "\\ $\\times$ Colombia",
    "inst_pre:factor(Country)MEX" = "\\ $\\times$ Mexico",
    "inst_pre:factor(Country)PER" = "\\ $\\times$ Peru",
    ln_Assets_USD = "Assets (log)",
    age = "Age",
    Finance = "Finance",
    Infraestructure = "Infrastructure",
    SOE_pre.IPO = "State-Owned"
  ),
  custom.header = list(
    "All Countries" = 1:2,
    "Excluding Brazil" = 3
  ),
  save = "TableG1_OA")

data_ipo = data_ipo %>%
  filter(!is.na(Family_Board), !is.na(inst_pre))
data_ipo$family.res = lm(
  Family_Board ~ Country + factor(Year) + age + ln_Assets_USD + Finance +
    Infraestructure + SOE_pre.IPO,
  data = data_ipo
) %>% resid()
data_ipo$inst_pre.res = lm(
  inst_pre ~ Country + factor(Year) + age + ln_Assets_USD + Finance +
    Infraestructure + SOE_pre.IPO,
  data = data_ipo
) %>% resid()

# Figure 10: Institutional Ownership and Family Ties

p = ggplot(data_ipo, aes(x = inst_pre.res, y = family.res)) +
  geom_point(color = "gray47") +
  geom_smooth(method = "lm", col = "black", alpha = .25,
              linetype = "dashed") +
  xlab("Residual of Share of Institutional Ownership Pre-IPO") +
  ylab("Residual of Number of Family Members")

print(p)
ggsave("figs/ipos.pdf", width = 5, height = 4)

print_tikz(p, "figs/Figure10.tex", width = 5, height = 4, standAlone = TRUE)


p = data_ipo %>%
  mutate(country = dplyr::recode(
    Country,
    ARG = "Argentina",
    BRA = "Brazil",
    CHI = "Chile",
    COL = "Colombia",
    MEX = "Mexico",
    PER = "Peru"
  )) %>%
  ggplot(aes(x = inst_pre.res, y = family.res)) +
  geom_point(color = "gray47") +
  geom_smooth(method = "lm", col = "black", alpha = .25,
              linetype = "dashed") +
  xlab("Residual of Share of Institutional Ownership Pre-IPO") +
  ylab("Residual of Number of Family Members") +
  facet_wrap(~ country)

print(p)

print_tikz(p, "figs/ipos_country.tex", width = 7, height = 5, standAlone = TRUE)


######################################################################~
# Entry of Institutional Investors ####
######################################################################~

# Figure 11: Entry of Institutional Investors and Family Ties

firms = import_csv("data/firms_merged.csv", encoding = "UTF-8")
firms_labels = import_csv("data/firms_labels.csv") %>%
  with(as.list(label) %>% set_names(variable))

firms_ = firms %>%
  drop_na(has_ties, n_ind_with_ties)

controls = expr(assets_log + income_log + age_log +
                  foreign + state_owned)

m1 = felm(has_ties ~ institutional_ownership + !!controls |
            industry + year | 0 | cnpj, firms_)

m2 = felm(has_ties ~ institutional_ownership |
            year + cnpj | 0 | cnpj, firms_)

m3 = felm(n_ind_with_ties ~ institutional_ownership + !!controls |
            industry + year | 0 | cnpj, firms_)

m4 = felm(n_ind_with_ties ~ institutional_ownership |
            year + cnpj | 0 | cnpj, firms_)

p = tibble(
  model = list(m1, m2, m3, m4),
  outcome = c(rep("Family Ties (Binary)", 2),
              rep("Number of Individuals with Ties", 2)),
  method = rep(c("Pooled Cross Section", "Firm Fixed Effects"), 2)
) %>%
  mutate(model = map(model, function(m) {
    tibble(conf.level = c(0.9, 0.95)) %>%
      mutate(model = map(conf.level,
                         ~ tidy(m, conf.int = TRUE, conf.level = .))) %>%
      unnest(model)
  })) %>%
  unnest(model) %>%
  filter(term == "institutional_ownership") %>%
  ggplot(aes(x = factor(method), y = estimate,
             ymin = conf.low, ymax = conf.high)) +
  facet_wrap(~ outcome, scales = "free_x") +
  geom_pointrange() +
  geom_linerange(size = 1.1, data = . %>% filter(conf.level == 0.9)) +
  geom_hline(yintercept = 0, linetype = 2, colour = "grey60") +
  theme_bw() +
  coord_flip() +
  xlab("") +
  ylab("Effect of Institutional Ownership")

print(p)
ggsave("figs/first_stage.pdf", width = 6, height = 2)

print_tikz(p, "figs/Figure11.tex",
           width = 6, height = 2, standAlone = TRUE)


# Table F1: Entry of Institutional Investors and Family Ties

list(m1, m2, m3, m4) %>%
  outreg(firms_labels,
         custom.header = list(
           "Family ties\n(Binary)" = 1:2,
           "Number of indivi-\nduals with ties" = 3:4
         ) %>% turn_multi_cell(),
         save = "TableF1")


######################################################################~
# Prevalence of Family Firms by Region ####
######################################################################~

# Figure B1: Family Firms and GDP per capita

ffs_country = read_csv("data/petopost.csv") %>%
  select(country, ownership, account_id) %>%
  mutate(id = row_number(), tmp = 1) %>%
  pivot_wider(names_from = ownership, values_from = tmp, values_fill = 0) %>%
  select(!id) %>%
  group_by(country, account_id) %>%
  summarise(across(everything(), mean)) %>%
  ungroup() %>%
  group_by(country) %>%
  summarise(across(!account_id, mean)) %>%
  mutate(family = Founder + `Family owned, family CEO`)

ffs_country_ = ffs_country %>%
  mutate(
    country = dplyr::recode(country, "Republic of Ireland" = "Ireland"),
    region = countrycode(country, 'country.name', 'region')
  ) %>%
  left_join(
    WDI(indicator='NY.GDP.PCAP.PP.CD', start = 2014, end = 2014) %>%
      as_tibble() %>%
      mutate(gdp = log(NY.GDP.PCAP.PP.CD)) %>%
      select(country, gdp)
  ) %>%
  select(country, region, gdp, family) %>%
  filter(region != "South Asia")

ffs_country_plot = ffs_country_ %>%
  mutate(aggregate = FALSE) %>%
  bind_rows(
    ffs_country_ %>%
      group_by(region) %>%
      summarise(across(c(family, gdp), mean),
                country = first(region)) %>%
      ungroup() %>%
      mutate(aggregate = TRUE)
  )

p = ffs_country_plot %>%
  mutate(across(c(region, country), str_replace, fixed("&"), "\\&")) %>%
  mutate(family = family * 100) %>%
  ggplot(aes(x = gdp, y = family)) +
  geom_point(aes(color = region, size = aggregate)) +#, size = aggregate)) +
  geom_smooth(method = "lm", col = "black", alpha = .5) +
  geom_text_repel(aes(label = country, size = aggregate,
                      alpha = aggregate)) +
  scale_size_manual(values = c(3, 4)) +
  theme(legend.position = "none") +
  xlab("Log GDP per capita PPP (2014)") +
  ylab("\\% Family Firms") +
  scale_alpha_manual(values = c(.5, 1))

print(p)
ggsave("figs/ffs_country.pdf", width = 5, height = 4)

print_tikz(p, "figs/FigureB1.tex", width = 5, height = 4,
           standAlone = TRUE)


######################################################################~
# Descriptive statistics ####
######################################################################~

# Table C2: Sample means of main variables by family-firm status

firms = import_csv("data/firms_merged.csv", encoding = "UTF-8")
firms_labels = import_csv("data/firms_labels.csv") %>%
  with(as.list(label) %>% set_names(variable))

firm_level = firms %>%
  mutate(has_contrib_total = 100 * (contrib_total > 0),
         finance = industry == "Finance") %>%
  group_by(cnpj) %>%
  summarise(
    across(c(family_firm, has_contrib_total, contrib_total,
             contrib_total_controlled_all, age),
           ~ max(., na.rm = TRUE) %>% na_if(-Inf)),
    across(c(n_ind_with_ties, board_size_all, assets_log, income_log),
           median, na.rm = TRUE),
    across(ordinary_shares_natural, ~ 100 * median(., na.rm = TRUE)),
    .groups = "drop"
  )

df = firm_level %>%
  select(!cnpj) %>%
  mutate(family_firm = ifelse(family_firm == 1, "Family firm", "Non-family firm")) %>%
  group_by(family_firm) %>%
  summarise(across(everything(), list(mean = mean, sd = sd), na.rm = TRUE),
            n = n()) %>%
  ungroup() %>%
  mutate(across(!family_firm, ~ round(., 1) %>% prettyNum(big.mark = ","))) %>%
  pivot_longer(!family_firm, names_to = "variable") %>%
  mutate(variable = str_remove(variable, "_mean$")) %>%
  pivot_wider(names_from = family_firm, values_from = value) %>%
  filter(variable != "has_contrib_total_sd") %>%
  left_join(read_csv("data/firms_labels.csv") %>%
              bind_rows(tibble(
                variable = c("board_size_all", "n"),
                label = c("Board + Top Management Size", "Number of Firms")
              )) %>%
              mutate(label = map_chr(label, multi_cell, align = "l", add = "\\\\quad ",
                                     pre = "\\multirow{2}{*}{", post = "}"))) %>%
  select(Variable = label, !variable) %>%
  mutate(across(!Variable, ~ ifelse(is.na(Variable), str_c("(", ., ")"), .)),
         across(Variable, replace_na, ""))

str_c(pmap_chr(df, str_c, sep = " & "),
      collapse = " \\\\\n") %>%
  str_replace_all(fixed("%"), "\\%") %>%
  str_c("\\begin{threeparttable}
         \\begin{tabular}{@{}lrr@{}}
         \\toprule & \\multicolumn{2}{c}{Sample Means} \\\\
         \\cmidrule{2-3} & Family Firms & Non-family Firms \\\\ \\midrule\n",
        .,
        "\n\\\\\\bottomrule
         \\end{tabular}\\begin{tablenotes}[para] \\footnotesize
         \\textit{Note}: Standard deviations in parentheses.
         \\end{tablenotes}
         \\end{threeparttable}") %>%
  save_latex_table("TableC2")


# Table K2 (Online Appendix): Variables definitions

firms_ = firms %>%
  mutate(bndes_ratio = ifelse(bndes_ratio > 1, NA, bndes_ratio))

summ = function(variable, f)
  map_dbl(variable, ~ ifelse(. == "industry", NA, f(firms_[[.]], na.rm = TRUE)))

read_csv("data/firms_labels.csv") %>%
  mutate(label = map_chr(label, multi_cell, align = "l", add = "\\\\quad ", option = "[t]"))

df = read_csv("data/var_definitions.csv") %>%
  left_join(read_csv("data/firms_labels.csv") %>%
              mutate(label = map_chr(label, multi_cell, align = "l",
                                     add = "\\\\quad ", option = "[t]"))) %>%
  mutate(Observations = map_int(variable, ~ sum(!is.na(firms_[[.]]))),
         Minimum = summ(variable, min),
         Maximum = summ(variable, max),
         Median = summ(variable, median),
         Mean = summ(variable, mean),
         "Std Dev" = summ(variable, sd)) %>%
  select(Variable = label, Description = description, Support = support,
         Source = source, Observations:`Std Dev`) %>%
  mutate(across(Observations:`Std Dev`,
                ~ ifelse(is.na(.), "",
                         round(., 1) %>% prettyNum(big.mark = ","))))

str_c(str_c(names(df) %>% str_c(collapse = " & "), "\\\\\n\\midrule\n"),
      str_c(pmap_chr(df, str_c, sep = " & "), collapse = " \\\\\n")) %>%
  str_replace_all(fixed("%"), "\\%") %>%
  str_c("\\begin{tabularx}{14in}{@{}lXllrrrrrr@{}}\\toprule\n",
        .,
        "\n\\\\\\bottomrule\\end{tabularx}") %>%
  save_latex_table(
    "TableK2_OA",
    add_to_header = "\\usepackage{tabularx}\\def\\R{\\mathbb{R}}\\def\\N{\\mathbb{N}}"
  )

# Table K3 (Online Appendix): Individual-Level Variables definitions

summ = function(variable, f)
  map_dbl(variable, ~ f(individuals[[.]], na.rm = TRUE))

individuals = import_csv("data/individuals_merged.csv", encoding = "UTF-8") %>%
  left_join(import_csv("data/firms_merged.csv", encoding="UTF-8") %>%
              filter(year <= 2014) %>%
              group_by(cnpj) %>%
              summarise(firm_contributed = any(contrib_total > 0),
                        firm_controlled_contributed = any(contrib_total_controlled_plus > 0),
                        bndes_bool = any(bndes_bool > 0)) %>%
              mutate_if(is.logical, as.numeric),
            by = c("cnpj")) %>%
  mutate(contrib_total_bool = as.numeric(contrib_total > 0),
         is_in_bod_and_management = is_manager * is_in_bod,
         shares_owns = as.numeric(shares_ordinary > 0),
         not_firm_controlled_contributed = 1 - firm_controlled_contributed,
         in_family = family_firm * has_tie)

df = read_csv("data/ind_var_definitions.csv") %>%
  left_join(read_csv("data/individuals_labels.csv")) %>%
  mutate(Observations = map_int(variable, ~ sum(!is.na(individuals[[.]]))),
         Minimum = summ(variable, min),
         Maximum = summ(variable, max),
         Median = summ(variable, median),
         Mean = summ(variable, mean),
         "Std Dev" = summ(variable, sd)) %>%
  select(Variable = label, Description = description, Support = support,
         Source = source, Observations:`Std Dev`) %>%
  mutate(across(Observations:`Std Dev`,
                ~ ifelse(is.na(.), "",
                         round(., 1) %>% prettyNum(big.mark = ","))))

str_c(str_c(names(df) %>% str_c(collapse = " & "), "\\\\\n\\midrule\n"),
      str_c(pmap_chr(df, str_c, sep = " & "), collapse = " \\\\\n")) %>%
  str_replace_all(fixed("%"), "\\%") %>%
  str_c("\\begin{tabularx}{14in}{@{}lXllrrrrrr@{}}\\toprule\n",
        .,
        "\n\\\\\\bottomrule\\end{tabularx}") %>%
  save_latex_table(
    "TableK3_OA",
    add_to_header = "\\usepackage{tabularx}\\def\\R{\\mathbb{R}}\\def\\N{\\mathbb{N}}"
    )


######################################################################~
# Sensitivity to Unobserved Selection ####
######################################################################~

# Figure H1 (Online Appendix): Sensitivity Analysis

firms = import_csv("data/firms_merged.csv", encoding = "UTF-8")

controls_full = expr(assets_log + income_log + age_log +
                       foreign + state_owned)

cg_controls = expr(ordinary_shares_natural + ordinary_herfindahl +
                     ordinary_shares_free_float_direct +
                     has_preferential_shares + largest_shareholder_gap)

m = lm(eval_formula(contrib_total_bool ~ family_firm +
                      !!cg_controls + !!controls_full + factor(year) + industry),
       firms)

sensitivity <- sensemakr(
  model = m,
  treatment = "family_firm",
  benchmark_covariates = c("ordinary_shares_natural",
                           "assets_log", "income_log", "age_log",
                           "foreign", "state_owned", "ordinary_shares_natural",
                           "ordinary_herfindahl",
                           "ordinary_shares_free_float_direct",
                           "has_preferential_shares", "largest_shareholder_gap"),
  kd = 1:2)
pdf("figs/FigureH1_OA.pdf")
plot(sensitivity)
dev.off()


# Figure H2 (Online Appendix): Sensitivity Analysis of 5.2.2

individuals <- import_csv("data/individuals_merged.csv", encoding="UTF-8") %>%
  select(contrib_total, has_tie_bool, is_manager, is_in_bod,
         shares_ordinary, public_sector, age_log, cnpj_year) %>%
  mutate(contrib_total_bool = as.numeric(contrib_total > 0),
         is_manager_and_in_bod = is_manager * is_in_bod) %>%
  drop_na()

get_projection = function(var) {
  felm(glue("{var} ~ 0 | cnpj_year") %>% as.formula(), individuals)$residuals %>%
    as.vector()
}

data = names(individuals) %>%
  set_names(., .) %>%
  map_dfc(get_projection)

m = lm(contrib_total_bool ~
         has_tie_bool + is_manager + is_manager_and_in_bod +
         shares_ordinary + public_sector + age_log,
       data)

sensitivity <- sensemakr(
  model = m,
  treatment = "has_tie_bool",
  benchmark_covariates = c("is_manager",
                           "is_manager_and_in_bod",
                           "shares_ordinary",
                           "public_sector",
                           "age_log"),
  kd = 1:2)
pdf("figs/FigureH2_OA.pdf")
plot(sensitivity)
dev.off()


######################################################################~
# Discussion of Heckman Models ####
######################################################################~

# Table J3 (Online Appendix): Table A1 using assets (log) as an instrument

firms = import_csv("data/firms_merged.csv", encoding = "UTF-8")
firms_labels = import_csv("data/firms_labels.csv") %>%
  with(as.list(label) %>% set_names(variable))

data_all = firms %>%
  select(contrib_total, contrib_total_controlled_plus,
         contrib_total_controlled_all, family_firm,
         ordinary_shares_natural, ordinary_herfindahl,
         ordinary_shares_free_float_direct,
         has_preferential_shares, largest_shareholder_gap,
         assets_log, income_log, age_log,
         foreign, state_owned, year, industry, cnpj)

data1 = data_all %>%
  select(!c(contrib_total_controlled_plus, contrib_total_controlled_all)) %>%
  drop_na()
seleq1 = glm(I(contrib_total>0) ~ family_firm +
               ordinary_shares_natural + ordinary_herfindahl +
               ordinary_shares_free_float_direct +
               has_preferential_shares + largest_shareholder_gap +
               assets_log + income_log + age_log +
               foreign + state_owned + factor(year) + industry,
             family = binomial(link="probit"),
             data = data1)
data1$IMR = dnorm(seleq1$linear.predictors)/pnorm(seleq1$linear.predictors)

m1 = felm(log(contrib_total) ~ family_firm +
            ordinary_shares_natural + ordinary_herfindahl +
            ordinary_shares_free_float_direct +
            has_preferential_shares + largest_shareholder_gap +
            age_log + income_log +
            foreign + state_owned + IMR |
            year + industry | 0 | cnpj,
          data1 %>% filter(contrib_total>0))

data2 = data_all %>%
  select(!c(contrib_total, contrib_total_controlled_all)) %>%
  drop_na()
seleq2 = glm(I(contrib_total_controlled_plus>0) ~ family_firm +
               ordinary_shares_natural + ordinary_herfindahl +
               ordinary_shares_free_float_direct +
               has_preferential_shares + largest_shareholder_gap +
               assets_log + income_log + age_log +
               foreign + state_owned + factor(year) + industry,
             family = binomial(link="probit"),
             data = data2)
data2$IMR = dnorm(seleq2$linear.predictors)/pnorm(seleq2$linear.predictors)

m2 = felm(log(contrib_total_controlled_plus) ~ family_firm +
            ordinary_shares_natural + ordinary_herfindahl +
            ordinary_shares_free_float_direct +
            has_preferential_shares + largest_shareholder_gap +
            age_log + income_log +
            foreign + state_owned + IMR |
            year + industry | 0 | cnpj,
          data2 %>% filter(contrib_total_controlled_plus>0))

data3 = data_all %>%
  select(!c(contrib_total, contrib_total_controlled_plus)) %>%
  drop_na()
seleq3 = glm(I(contrib_total_controlled_all>0) ~ family_firm +
               ordinary_shares_natural + ordinary_herfindahl +
               ordinary_shares_free_float_direct +
               has_preferential_shares + largest_shareholder_gap +
               assets_log + income_log + age_log +
               foreign + state_owned + factor(year) + industry,
             family = binomial(link="probit"),
             data = data3)
data3$IMR = dnorm(seleq3$linear.predictors)/pnorm(seleq3$linear.predictors)

m3 = felm(log(contrib_total_controlled_all) ~ family_firm +
            ordinary_shares_natural + ordinary_herfindahl +
            ordinary_shares_free_float_direct +
            has_preferential_shares + largest_shareholder_gap +
            age_log + income_log +
            foreign + state_owned + IMR |
            year + industry | 0 | cnpj,
          data3 %>% filter(contrib_total_controlled_all>0))

list(m1, m2, m3) %>%
  outreg(firms_labels,
         custom.header = list("Contributions (log) by" = 1:3),
         custom.model.names =
           c("Firm", "Firm + Subsidiaries", "Firm + Leadership") %>%
           add_model_numbers(),
         treatment = "family_firm",
         save = "TableJ3_OA")


# Table J4 (Online Appendix): Table A1 using income (log) as an instrument

data_all = firms %>%
  select(contrib_total, contrib_total_controlled_plus,
         contrib_total_controlled_all, family_firm,
         ordinary_shares_natural, ordinary_herfindahl,
         ordinary_shares_free_float_direct,
         has_preferential_shares, largest_shareholder_gap,
         assets_log, income_log, age_log,
         foreign, state_owned, year, industry, cnpj)

data1 = data_all %>%
  select(!c(contrib_total_controlled_plus, contrib_total_controlled_all)) %>%
  drop_na()
seleq1 = glm(I(contrib_total>0) ~ family_firm +
               ordinary_shares_natural + ordinary_herfindahl +
               ordinary_shares_free_float_direct +
               has_preferential_shares + largest_shareholder_gap +
               assets_log + income_log + age_log +
               foreign + state_owned + factor(year) + industry,
             family = binomial(link="probit"),
             data = data1)
data1$IMR = dnorm(seleq1$linear.predictors)/pnorm(seleq1$linear.predictors)

m1 = felm(log(contrib_total) ~ family_firm +
            ordinary_shares_natural + ordinary_herfindahl +
            ordinary_shares_free_float_direct +
            has_preferential_shares + largest_shareholder_gap +
            age_log + assets_log +
            foreign + state_owned + IMR |
            year + industry | 0 | cnpj,
          data1 %>% filter(contrib_total>0))

data2 = data_all %>%
  select(!c(contrib_total, contrib_total_controlled_all)) %>%
  drop_na()
seleq2 = glm(I(contrib_total_controlled_plus>0) ~ family_firm +
               ordinary_shares_natural + ordinary_herfindahl +
               ordinary_shares_free_float_direct +
               has_preferential_shares + largest_shareholder_gap +
               assets_log + income_log + age_log +
               foreign + state_owned + factor(year) + industry,
             family = binomial(link="probit"),
             data = data2)
data2$IMR = dnorm(seleq2$linear.predictors)/pnorm(seleq2$linear.predictors)

m2 = felm(log(contrib_total_controlled_plus) ~ family_firm +
            ordinary_shares_natural + ordinary_herfindahl +
            ordinary_shares_free_float_direct +
            has_preferential_shares + largest_shareholder_gap +
            age_log + assets_log +
            foreign + state_owned + IMR |
            year + industry | 0 | cnpj,
          data2 %>% filter(contrib_total_controlled_plus>0))

data3 = data_all %>%
  select(!c(contrib_total, contrib_total_controlled_plus)) %>%
  drop_na()
seleq3 = glm(I(contrib_total_controlled_all>0) ~ family_firm +
               ordinary_shares_natural + ordinary_herfindahl +
               ordinary_shares_free_float_direct +
               has_preferential_shares + largest_shareholder_gap +
               assets_log + income_log + age_log +
               foreign + state_owned + factor(year) + industry,
             family = binomial(link="probit"),
             data = data3)
data3$IMR = dnorm(seleq3$linear.predictors)/pnorm(seleq3$linear.predictors)

m3 = felm(log(contrib_total_controlled_all) ~ family_firm +
            ordinary_shares_natural + ordinary_herfindahl +
            ordinary_shares_free_float_direct +
            has_preferential_shares + largest_shareholder_gap +
            age_log + assets_log +
            foreign + state_owned + IMR |
            year + industry | 0 | cnpj,
          data3 %>% filter(contrib_total_controlled_all>0))

list(m1, m2, m3) %>%
  outreg(firms_labels,
         custom.header = list("Contributions (log) by" = 1:3),
         custom.model.names =
           c("Firm", "Firm + Subsidiaries", "Firm + Leadership") %>%
           add_model_numbers(),
         treatment = "family_firm",
         save = "TableJ4_OA")


# Table J1 (Online Appendix): Table D2 using assets (log) as an instrument

m_pt = selection(I(contrib_total_controlled_all>0) ~
                   !!family_firm_sectors + !!controls + as.factor(year),
                 I(contrib_pt_controlled_all/contrib_total_controlled_all) ~
                   !!family_firm_sectors + income_log + age_log + as.factor(year),
                 firms %>% filter(!foreign, !state_owned),
                 method = "2step")

m_pmdb = selection(I(contrib_total_controlled_all>0) ~
                     !!family_firm_sectors + !!controls + as.factor(year),
                   I(contrib_mdb_controlled_all/contrib_total_controlled_all) ~
                     !!family_firm_sectors + income_log + age_log + as.factor(year),
                   firms %>% filter(!foreign, !state_owned),
                   method = "2step")

m_psdb = selection(I(contrib_total_controlled_all>0) ~
                     !!family_firm_sectors + !!controls + as.factor(year),
                   I(contrib_psdb_controlled_all/contrib_total_controlled_all) ~
                     !!family_firm_sectors + income_log + age_log + as.factor(year),
                   firms %>% filter(!foreign, !state_owned),
                   method = "2step")

m_party = selection(I(contrib_total_controlled_all>0) ~
                      !!family_firm_sectors + !!controls + as.factor(year),
                    I(contrib_par_controlled_all/contrib_total_controlled_all) ~
                      !!family_firm_sectors + income_log + age_log + as.factor(year),
                    firms %>% filter(!foreign, !state_owned),
                    method = "2step")

m_incumbent = selection(I(contrib_total_controlled_all>0) ~
                          !!family_firm_sectors + !!controls + as.factor(year),
                        I(contrib_incumbent_controlled_all/contrib_total_controlled_all) ~
                          !!family_firm_sectors + income_log + age_log + as.factor(year),
                        firms %>% filter(!foreign, !state_owned),
                        method = "2step")

m_insider = selection(I(contrib_total_controlled_all>0) ~
                        !!family_firm_sectors + !!controls + as.factor(year),
                      I(contrib_insider_controlled_all/contrib_total_controlled_all) ~
                        !!family_firm_sectors + income_log + age_log + as.factor(year),
                      firms %>% filter(!foreign, !state_owned),
                      method = "2step")

m_business = selection(I(contrib_total_controlled_all>0) ~
                         !!family_firm_sectors + !!controls + as.factor(year),
                       I(contrib_business_controlled_all/contrib_total_controlled_all) ~
                         !!family_firm_sectors + income_log + age_log + as.factor(year),
                       firms %>% filter(!foreign, !state_owned),
                       method = "2step")

m_num_parties = selection(I(contrib_total_controlled_all>0) ~
                            !!family_firm_sectors + !!controls + as.factor(year),
                          contrib_n_parties_controlled_all ~
                            !!family_firm_sectors + income_log + age_log + as.factor(year),
                          firms %>% filter(!foreign, !state_owned),
                          method = "2step")

outcomes = c("Parties", "Incumbents", "PT", "MDB", "PSDB",
             "Career Politician/#Bureaucrat", "Business#Candidates")

list(m_party, m_incumbent, m_pt, m_pmdb, m_psdb, m_insider, m_business) %>%
  outreg(firms_labels,
         custom.header = as.list(1:length(outcomes)) %>%
           set_names(outcomes %>% map_chr(multi_cell, sep = "#")),
         stars = c(0.05, 0.01, 0.001),
         fe = c("Year", "Industry"),
         save = "TableJ1_OA")


# Table J2 (Online Appendix): Table D2 using age (log) as an instrument

family_firm_sectors = expr(family_firm + industry)
controls = expr(assets_log + income_log + age_log)

m_pt = selection(I(contrib_total_controlled_all>0) ~
                   !!family_firm_sectors + !!controls + as.factor(year),
                 I(contrib_pt_controlled_all/contrib_total_controlled_all) ~
                   !!family_firm_sectors + assets_log + income_log + as.factor(year),
                 firms %>% filter(!foreign, !state_owned),
                 method = "2step")

m_pmdb = selection(I(contrib_total_controlled_all>0) ~
                     !!family_firm_sectors + !!controls + as.factor(year),
                   I(contrib_mdb_controlled_all/contrib_total_controlled_all) ~
                     !!family_firm_sectors + assets_log + income_log + as.factor(year),
                   firms %>% filter(!foreign, !state_owned),
                   method = "2step")

m_psdb = selection(I(contrib_total_controlled_all>0) ~
                     !!family_firm_sectors + !!controls + as.factor(year),
                   I(contrib_psdb_controlled_all/contrib_total_controlled_all) ~
                     !!family_firm_sectors + assets_log + income_log + as.factor(year),
                   firms %>% filter(!foreign, !state_owned),
                   method = "2step")

m_party = selection(I(contrib_total_controlled_all>0) ~
                      !!family_firm_sectors + !!controls + as.factor(year),
                    I(contrib_par_controlled_all/contrib_total_controlled_all) ~
                      !!family_firm_sectors + assets_log + income_log + as.factor(year),
                    firms %>% filter(!foreign, !state_owned),
                    method = "2step")

m_incumbent = selection(I(contrib_total_controlled_all>0) ~
                          !!family_firm_sectors + !!controls + as.factor(year),
                        I(contrib_incumbent_controlled_all/contrib_total_controlled_all) ~
                          !!family_firm_sectors + assets_log + income_log + as.factor(year),
                        firms %>% filter(!foreign, !state_owned),
                        method = "2step")

m_insider = selection(I(contrib_total_controlled_all>0) ~
                        !!family_firm_sectors + !!controls + as.factor(year),
                      I(contrib_insider_controlled_all/contrib_total_controlled_all) ~
                        !!family_firm_sectors + assets_log + income_log + as.factor(year),
                      firms %>% filter(!foreign, !state_owned),
                      method = "2step")

m_business = selection(I(contrib_total_controlled_all>0) ~
                         !!family_firm_sectors + !!controls + as.factor(year),
                       I(contrib_business_controlled_all/contrib_total_controlled_all) ~
                         !!family_firm_sectors + assets_log + income_log + as.factor(year),
                       firms %>% filter(!foreign, !state_owned),
                       method = "2step")

list(m_party, m_incumbent, m_pt, m_pmdb, m_psdb, m_insider, m_business) %>%
  outreg(firms_labels,
         custom.header = as.list(1:length(outcomes)) %>%
           set_names(outcomes %>% map_chr(multi_cell, sep = "#")),
         stars = c(0.05, 0.01, 0.001),
         fe = c("Year", "Industry"),
         save = "TableJ2_OA")

