## Note: You will need to install the following packages

library(magrittr)
library(lubridate)
library(tidyverse)
library(rio)
library(lfe)
library(texreg)
library(tools)
library(rlang)
library(tikzDevice)
library(estimatr)
library(stringi)
library(glue)
library(readxl)
library(clipr)
library(sampleSelection)
library(fs)
library(WDI)
library(countrycode)
library(ggrepel)
library(sensemakr)

options(stringsAsFactors = FALSE)
options(scipen = 10)
theme_set(theme_bw() +
            theme(panel.grid.minor = ggplot2::element_blank(),
                  panel.grid.major.x = ggplot2::element_blank(),
                  panel.grid.major.y = ggplot2::element_blank()))

table = function(..., useNA = 'ifany') base::table(..., useNA = useNA)
import_csv = function(file, ..., keepLeadingZeros = TRUE, setclass = "tibble")
  rio::import(file, ..., keepLeadingZeros = keepLeadingZeros, setclass = setclass)
import_str = function(..., colClasses = "character") rio::import(..., colClasses = colClasses)
count = function(..., sort = TRUE) dplyr::count(..., sort = sort)
normalize_string = function(s)
  str_squish(str_remove_all(str_to_upper(stri_trans_general(s, "latin-ascii")), "[^A-Z ]"))

eval_formula = function(x, ...) eval(expr(expr(!!x)), ...)
lm_robust = function(formula, ...) estimatr::lm_robust(eval_formula(formula), ...)
felm = function(formula, ..., keepX = TRUE)
  lfe::felm(eval_formula(formula), ..., keepX = keepX)
selection = function(selection, outcome, ...) {
  sampleSelection::selection(eval_formula(selection),
                             eval_formula(outcome), ...,
                             xo = TRUE, yo = TRUE)
}

residualize = function(x, col = NULL) {
  if(is.null(col)) col = names(x)[1]
  complete_rows = !rowSums(is.na(x))
  ret = rep(NA, nrow(x))
  ret[complete_rows] =
    residuals(lm(paste(col, "~ ."), x[complete_rows, ]))
  return(ret)
}

`%wo%` = function(a, b) discard(a, `==`, b)

tidy.selection = function(m, conf.int = TRUE, conf.level = 0.95) {
  s = summary(m)
  s$estimate[s$param$index$betaO, ] %>%
    as_tibble(rownames = "term") %>%
    janitor::clean_names() %>%
    rename(std.error = std_error,
           statistic = t_value,
           p.value = pr_t) %>%
    mutate(conf.low = estimate - qnorm(conf.level) * std.error,
           conf.high = estimate + qnorm(conf.level) * std.error)
}

nchar_distinct = function(s) sapply(str_split(s, ""), n_distinct)

save_latex_table = function(latex_table, save, add_to_header = "") {
  str_c("\\documentclass[border=10pt]{standalone}
           \\usepackage{amssymb,booktabs,dcolumn,multirow}
           \\usepackage[flushleft]{threeparttable}
           \\usepackage[utf8]{inputenc}
           \\newcommand\\mc[1]{\\multicolumn{1}{c}{#1}}",
        add_to_header,
        "\\begin{document}") %>%
    str_squish() %>%
    str_c("\n",
          latex_table,
          "\n\\end{document}\n") %>%
    write_file(str_c("tables/", save, ".tex"))
}

texreg_ = function(..., outcome = "", caption = NULL, label = NULL) {
  texreg(..., digits = 3, booktabs = TRUE, dcolumn = TRUE,
         caption.above = TRUE, center = FALSE, use.packages = FALSE,
         no.margin = TRUE, float.pos = "H", label = label, caption = caption) %>%
    str_replace("\\Q\\begin{tabular}{\\E",
                paste0(outcome, "\\\\centering<br>
                       \\\\begin{threeparttable}<br>
                       \\\\begin{tabular}{@{}")) %>%
    str_remove(fixed("\\label{}")) %>%
    str_replace(fixed("\\end{tabular}\n"),
                "\\end{tabular}<br>
                \\begin{tablenotes}[para] \\footnotesize<br>
                \\textit{Notes}: <br>
                \\\\$^{***}p<0.01$; $^{**}p<0.05$; $^{*}p<0.1$<br>
                \\end{tablenotes}<br>
                \\end{threeparttable}<br>") %>%
    str_remove("\\\\multicolumn.*scriptsize.*\\}\\}")
}
outreg = function(x, custom.coef.map = firms_labels, save = NULL,
                  stars = c(0.1, 0.05, 0.01), ...) {
  custom.coef.map = custom.coef.map %>%
    map(multi_cell, align = "l", add = "\\\\quad ",
        pre = "\\multirow{2}{*}{", post = "}")
  out <-
    texreg_(x, custom.coef.map = custom.coef.map, stars = stars, ...) %>%
    str_squish() %>%
    str_replace_all("<br>[ ]*", "\n") %>%
    str_replace_all("\\\\\\\\ ", "\\\\\\\\\n") %>%
    str_replace_all("Model ([0-9]+)", "(\\1)") %>%
    str_replace_all("&\\s(\\d+)\\s", "& \\\\mc{\\1} ") %>%
    str_replace_all(fixed("\\mc{1}"), "\\mc{\\checkmark}")
  if(is.null(save)) {
    write_clip(out)
  } else {
    out <- out %>%
      str_replace(fixed("\\begin{table}[H] \\caption{} \\centering"), "") %>%
      str_replace(fixed("\\end{table}"), "")
    save_latex_table(out, save)
  }
}

my.extract.felm <- function(model, treatment = NULL, ...) {
  s <- summary(model, ...)
  nam <- rownames(s$coefficients)
  co <- s$coefficients[, 1]
  se <- s$coefficients[, 2]
  pval <- s$coefficients[, 4]

  gof <- numeric()
  gof.names <- character()
  gof.decimal <- logical()

  if(!is.null(treatment)) {
    y_mean = model$X %>%
      cbind(model$response) %>%
      as_tibble() %>%
      rename(y = last_col()) %>%
      filter(rowSums(.[intersect(treatment, names(.))]) == 0) %>%
      summarise(y_mean = mean(y)) %>%
      pull(y_mean)

    gof <- c(gof, y_mean)
    gof.names <- c(gof.names, "Control Outcome Mean")
    gof.decimal <- c(gof.decimal, TRUE)
  }

  gof <- c(gof, s$N)
  gof.names <- c(gof.names, "Observations")
  gof.decimal <- c(gof.decimal, FALSE)

  gof <- c(gof, s$r2adj)
  gof.decimal <- c(gof.decimal, TRUE)
  gof.names <- c(gof.names, "Adjusted R$^2$")

  format_group_names <- function(group_names) {
    group_names %>%
      dplyr::recode(cnpj = "Firm",
                    cnpj_year = "Firm $\\times$ Year",
                    cpf = "Individual") %>%
      map_chr(~ str_c(str_to_upper(str_sub(., 1, 1)),
                      str_sub(., 2)))
  }

  if (length(s$fe) > 0) {
    grp <- sapply(s$fe, function(x) length(levels(x)))
    grp.names <- names(grp) %>% format_group_names() %>% str_c(" FE")
    gof <- c(gof, rep(1, length(grp))) # grp)
    gof.names <- c(gof.names, grp.names)
    gof.decimal <- c(gof.decimal, rep(FALSE, length(grp)))
  }

  createTexreg(coef.names = nam, coef = co, se = se, pvalues = pval,
               gof.names = gof.names, gof = gof, gof.decimal = gof.decimal)
}

setMethod("extract", signature = className("felm", "lfe"),
          definition = my.extract.felm)


my.extract.selection <- function(model, treatment = NULL, fe = character(), ...) {
  s <- summary(model, ...)
  coefs <- coef(model)
  coef.tab <- coef(s)
  rn <- names(coefs)
  se <- coef.tab[, 2]
  p <- coef.tab[, 4]
  include <- s$param$index$outcome
  coefs <- coefs[include]
  rn <- rn[include]
  se <- se[include]
  p <- p[include]

  gof <- numeric()
  gof.names <- character()
  gof.decimal <- logical()

  if(!is.null(treatment)) {
    y_mean = model$lm$model$XO %>%
      cbind(model$lm$model$YO) %>%
      as_tibble() %>%
      rename(y = last_col()) %>%
      filter(rowSums(.[intersect(treatment, names(.))]) == 0) %>%
      summarise(y_mean = mean(y)) %>%
      pull(y_mean)

    gof <- c(gof, y_mean)
    gof.names <- c(gof.names, "Control Outcome Mean")
    gof.decimal <- c(gof.decimal, TRUE)
  }

  gof <- c(gof, s$param$nObs, s$param$N0, s$param$N1)
  gof.names <- c(gof.names, "Observations", "Censored", "Observed")
  gof.decimal <- c(gof.decimal, FALSE, FALSE, FALSE)

  gof <- c(gof, s$rSquared$R2adj)
  gof.names <- c(gof.names, "Adjusted R$^2$")
  gof.decimal <- c(gof.decimal, TRUE)

  if (length(fe) > 0) {
    gof <- c(gof, rep(1, length(fe)))
    gof.names <- c(gof.names, str_c(fe, " FE"))
    gof.decimal <- c(gof.decimal, rep(FALSE, length(fe)))
  }

  createTexreg(coef.names = rn, coef = coefs, se = se, pvalues = p,
               gof.names = gof.names, gof = gof, gof.decimal = gof.decimal)
}

setMethod("extract", signature = className("selection", "sampleSelection"),
          definition = my.extract.selection)


multi_cell = function(x, sep = "\n", align = "c",
                      add = "", pre = "", post = "", option = "") {
  if(str_detect(x, sep))
    str_c(pre, "\\begin{tabular}", option, "{@{}", align, "@{}}",
          str_replace_all(x, sep, str_c("\\\\\\\\", add)),
          "\\end{tabular}", post)
  else x
}
turn_multi_cell = function(x, ...) {
  set_names(x, map_chr(names(x), multi_cell, ...))
}

add_model_numbers = function(x) {
  str_c(x, "\n(", 1:length(x), ")") %>%
    map_chr(multi_cell)
}

options(tikzLatexPackages =
          c(getOption("tikzLatexPackages"), "\\usepackage{mathptmx}"),
        tikzDocumentDeclaration = "\\documentclass[12pt]{article}")

print_tikz = function(p, file, width = 6, height = 4, standAlone = FALSE, ...) {
  tikz(file = file, width = width, height = height, standAlone = standAlone, ...)
  print(p)
  dev.off()
  if(standAlone) {
    wd = getwd()
    setwd(path_dir(file))
    texi2pdf(path_file(file), clean = TRUE)
    setwd(wd)
  }
}
