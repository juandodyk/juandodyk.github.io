##Cambiar el Folder
setwd("C:/Juan/dump/econ/ei/Calvo-Pomares-Transferencia PASO-GENERAL en R")

library(foreign)

ei.lls <- function(A, B, RetTotal=FALSE) {
  n <- ncol(A)
  m <- ncol(B)
  
  myind <- function(i, j) (i-1)*m+(j-1)+1
  AA <- t(A) %*% A
  AB <- t(A) %*% B
  Dmat <- matrix(0, nrow=n*m, ncol=n*m)
  for(i1 in 1:n) for(i2 in 1:n) for(j in 1:m)
    Dmat[myind(i1,j), myind(i2,j)] <- AA[i1, i2]
  dvec <- 1:(n*m)
  for(i in 1:n) for(j in 1:m) dvec[myind(i,j)] <- AB[i,j]
  off <- n#+m
  Amat <- matrix(0, nrow=n*m+off, ncol=n*m)
  bvec <- 1:(n*m+off)
  for(i in 1:n) for(j in 1:m) { Amat[i, myind(i, j)] <- 1; bvec[i] <- 1; }
  #TA <- sum(TotA); TB <- sum(TotB);
  #for(j in 1:m) for(i in 1:n) { Amat[j+n, myind(i, j)] <- TotA[i]/TA; bvec[j+n] <- TotB[j]/TB; }
  for(ij in 1:(n*m)) { Amat[ij+off, ij] <- 1; bvec[ij+off] <- 0; }
  
  sc <- norm(Dmat,"2")
  require(quadprog)
  tryCatch({
    sol <- solve.QP(Dmat/sc, dvec/sc, t(Amat), bvec, meq=off)
    S <- matrix(sol$solution, nrow=n, ncol=m, byrow=TRUE)
    
    if(RetTotal)
      for(i in 1:n) S[i,]<-S[i,]*sum(A[,i])
    return(S)
  }, error=function(e) {
    return(matrix(0, nrow=n, ncol=m));
  })
}

ei.lls.totales <- function(A, B, Tot=FALSE) {
  A <- as.matrix(A)
  B <- as.matrix(B)
  w <- intersect(which(rowSums(A[,1:6])>0), which(rowSums(B[,1:2])>0))
  A <- A[w,]
  B <- B[w,]
  A[,7] <- A[,9] - rowSums(A[,1:6])
  B[,3] <- B[,5] - rowSums(B[,1:2])
  A <- A[,1:7]; B <- B[,1:3]
  #A <- A/rowSums(A)
  #B <- B/rowSums(B)
  S<-ei.lls(A, B, RetTotal = Tot)
  colnames(S)<-colnames(B)
  rownames(S)<-colnames(A)
  return(S)
}

primera_segunda_prov <- function(data, p=NULL) {
  if(!is.null(p))
    w <- which(grepl(p, data[,1]))
  else
    w <- 1:nrow(data)
  tryCatch(ei.lls.totales(data[w,2:10], data[w,11:15], Tot=TRUE), error=function(e) return(matrix(0, nrow=7, ncol=3)))
}

primera_segunda <- function(prov=FALSE,ag=FALSE,dist=FALSE) {
  data <- read.csv('mesas_pri_seg.csv')
  if(prov) {
    S<-primera_segunda_prov(data, paste("^",prov,",",sep=""))
  } else if(ag) {
    S<-matrix(0, nrow=7, ncol=3)
    for(p in 1:24)
      S <- S + primera_segunda_prov(data, paste("^",p,",",sep=""))
  } else if(dist) {
    X <- (function(x) substr(x, 1, attr(regexpr("^[^,]+,[^,]+", x),"match.length")))(data[,1])
    X <- unique(X)
    S<-matrix(0, nrow=7, ncol=3)
    for(x in X)
      S <- S + primera_segunda_prov(data, paste("^",x,",",sep=""))
  } else {
    S<-primera_segunda_prov(data)
  }
  S <- S/rowSums(S)
  return(S)
}

show <- function(S) {
  X <- paste("| ", apply(round(S*100,2), 1, paste, collapse="% | "), "%", sep="")
  print(paste(paste("Scioli", X[1]), paste("Macri",X[4]), paste("Massa",X[6]), paste("Del Ca�o",X[5]), paste("Stolbizer",X[2]), paste("Rodr�guez Sa�",X[3]), paste("No Vot�/Blanco",X[7]), sep="\n"))
}

# prov=p calcula la matriz en la provincia p
# ag=TRUE calcula la matriz en cada provincia y devuelve la suma
# dist=TRUE hace lo mismo por departamento
# sin argumentos: calcula directamente la matriz a nivel nacional
S <- primera_segunda()
print(round(S*100,2))
