# Nonlinear least-squares estimate for the MD model by quadratic programming

setwd('~/Dropbox/infecologica/duke/')

ei.lls <- function(A, B, RetTotal=FALSE) {
  #A <- A/rowSums(A); B <- B/rowSums(B)
  n <- ncol(A)
  m <- ncol(B)
  
  myind <- function(i, j) (i-1)*m+(j-1)+1
  AA <- t(A) %*% A
  AB <- t(A) %*% B
  Dmat <- matrix(0, nrow=n*m, ncol=n*m)
  for(i1 in 1:n) for(i2 in 1:n) for(j in 1:m)
    Dmat[myind(i1,j), myind(i2,j)] <- AA[i1, i2]
  dvec <- 1:(n*m)
  for(i in 1:n) for(j in 1:m) dvec[myind(i,j)] <- AB[i,j]
  off <- n#+m
  Amat <- matrix(0, nrow=n*m+off, ncol=n*m)
  bvec <- numeric(n*m+off)
  for(i in 1:n) for(j in 1:m) { Amat[i, myind(i, j)] <- 1; bvec[i] <- 1; }
  TA <- apply(A, 2, sum)
  TB <- apply(B, 2, sum)
  #for(j in 1:m) for(i in 1:n) { Amat[j+n, myind(i, j)] <- TA[i]; bvec[j+n] <- TB[j]; }
  for(ij in 1:(n*m)) { Amat[ij+off, ij] <- 1; bvec[ij+off] <- 0; }
  
  sc <- norm(Dmat,"2")
  require(quadprog)
  tryCatch({
    sol <- solve.QP(Dmat/sc, dvec/sc, t(Amat), bvec, meq=off)
    S <- matrix(sol$solution, nrow=n, ncol=m, byrow=TRUE)
    print(paste("RMSE:", sqrt(mean((A %*% S-B)^2))))
    
    if(RetTotal)
      for(i in 1:n) S[i,]<-S[i,]*sum(A[,i])
    return(S)
  }, error=function(e) {
    return(matrix(0, nrow=n, ncol=m));
  })
}

ei.lls.totals <- function(data, R, C) {
  w <- intersect(which(rowSums(data[,2:R])>0), which(rowSums(data[,(R+2):(R+C)])>0))
  data <- data[w,]
  print(nrow(data))
  A <- as.matrix(data[,2:(R+1)])
  B <- as.matrix(data[,(R+2):(R+C+1)])
  A[,R] <- A[,R] - rowSums(A[,1:(R-1)])
  B[,C] <- B[,C] - rowSums(B[,1:(C-1)])
  A <- A/rowSums(A)
  B <- B/rowSums(B)
  S<-ei.lls(A, B)
  colnames(S)<-colnames(B)
  rownames(S)<-colnames(A)
  print(round(S,2))
  R <- A %*% S-B
  print(mean(R^2))
  S
}

data <- read.csv('mesas_paso.csv')
ei.lls.totals(data, 12, 7)
