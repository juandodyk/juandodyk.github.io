# Python implementation (using Tensorflow) of the Multinomial-Dirichlet nonlinear least-squares estimator controlling for spatial heterogeneity.
# main() produces a Pickle file, eish.p, with the results of Cross-Validation
# main2() produces Pickle file, beta.p and betas.p, with the global voter transition table for the best lambda (provided by Cross-Validation) and local -for each district- mean betas, respectively.

#!/usr/bin/python3
import csv, random, math, pickle, time, copy
import matplotlib.pyplot as plt
import numpy as np
np.set_printoptions(suppress=True)
import tensorflow as tf

class EISH():
    def __init__(self, xs, ys, ds, R, C, graph):
        self.R, self.C = R, C
        self.xs, self.ys, self.ds = xs, ys, ds
        self.graph = graph
        self.N = len(self.xs)
        self.D = D = max(self.ds)+1
        self.bfgs_options = {} #{'maxiter': 1000000, 'gtol':1e-8, 'maxfun':1000000}
        self.inicializar()
    def init_gammas(self):
        R, C, D = self.R, self.C, self.D
        x = tf.placeholder_with_default(tf.to_double(self.xs), [None, R])
        y_ = tf.placeholder_with_default(tf.to_double(self.ys), [None, C])
        W = tf.Variable(tf.random_normal([R, C-1], stddev=1, dtype=tf.float64))
        Beta = tf.nn.softmax(tf.concat(1, [W, tf.to_double(tf.zeros([R,1]))]))
        y = tf.matmul(x, Beta)
        gammas = tf.tile(tf.reshape(W, [1,R*(C-1)]), [D,1])
        error = tf.reduce_mean(tf.square(y - y_))
        optimizer = tf.contrib.opt.ScipyOptimizerInterface(error, options=self.bfgs_options)
        with tf.Session() as sess:
            sess.run(tf.initialize_all_variables())
            print("Goodman:")
            optimizer.minimize(session=sess)
            print(sess.run(Beta))
            init_gammas = sess.run(gammas)
        tf.reset_default_graph()
        return init_gammas
    def inicializar(self):
        print("Inicializando..."); _t = time.clock()
        R, C, D = self.R, self.C, self.D
        init_gammas = self.init_gammas()
        x = self.x = tf.placeholder_with_default(tf.to_double(self.xs), [None, R]) # [_, R]
        d = self.d = tf.placeholder_with_default(self.ds, [None]) # [_]
        y_ = self.y_ = tf.placeholder_with_default(tf.to_double(self.ys), [None, C]) # [_, C]
        lam = self.lam = tf.Variable(tf.to_double(2.), trainable=False)
        gammas = self.gammas = tf.Variable(init_gammas) # [D, R*(C-1)]
        W = tf.gather(gammas, d) # [_, R*(C-1)]
        Wr = tf.reshape(W, [-1, C-1]) # [_, C-1]
        zeros = tf.zeros([tf.shape(Wr)[0], 1], dtype=tf.float64) # [_, 1]
        soft = tf.nn.softmax(tf.concat(1, [Wr, zeros])) # [_, C]
        soft = tf.reshape(soft, [-1, R, C]) # [_, R, C]
        #xnorm = x / tf.expand_dims(tf.reduce_sum(x, reduction_indices=[1]), 1)
        Xs = tf.expand_dims(x, 1) # [_, 1, R]
        y = tf.squeeze(tf.batch_matmul(Xs, soft)) # [_, C]
        graph = self.graph
        ps, ps_, ds, m = tf.constant(graph[0]), tf.constant(graph[1]), tf.constant(graph[2], dtype=tf.float64), len(graph[0])
        assert max(graph[0]) < D and max(graph[1]) < D
        #beta_u = tf.reshape(tf.nn.softmax(tf.concat(1, [tf.reshape(tf.gather(gammas, ps), [-1, C-1]), tf.zeros([R*m, 1], dtype=tf.float64)])), [-1, R*C])
        #beta_v = tf.reshape(tf.nn.softmax(tf.concat(1, [tf.reshape(tf.gather(gammas, ps_), [-1, C-1]), tf.zeros([R*m, 1], dtype=tf.float64)])), [-1, R*C])
        #betas_diff = beta_u - beta_v
        betas_diff = tf.gather(gammas, ps) - tf.gather(gammas, ps_)
        self.penn = tf.reduce_mean(ds * tf.reduce_sum(tf.square(betas_diff), reduction_indices=[1]))
        #ynorm = y / tf.expand_dims(tf.reduce_sum(y, reduction_indices=[1]), 1)
        self.mse = tf.reduce_mean(tf.square(y - y_))
        self.error = self.mse + lam*self.penn
        Xsr = tf.reshape(Xs, [-1, R, 1]) # [_, R, 1]
        XB = tf.mul(tf.tile(Xsr, [1, 1, C]), soft) # [_, R, C]
        SX = tf.tile(tf.reduce_sum(Xsr, [0]), [1, C]) # [1, R, C]
        self.Beta = tf.reduce_sum(XB, [0]) / SX # [1, R, C]
        self.optimizer = tf.contrib.opt.ScipyOptimizerInterface(self.error, options=self.bfgs_options)
        print("...terminé de inicializar en %.3f segundos." % (time.clock() - _t))
        return self
    def train(self, sess, lam):
        _t = time.clock()
        feed_dict_train = {self.x: self.xs_train, self.y_: self.ys_train, self.d: self.ds_train}
        feed_dict_test = {self.x: self.xs_test, self.y_: self.ys_test, self.d: self.ds_test}
        sess.run(self.lam.assign(lam))
        print("ERROR:", sess.run(self.error), "MSE:", sess.run(self.mse), "PENN:", sess.run(self.penn))
        _t_bfgs = time.clock()
        self.optimizer.minimize(session=sess, feed_dict=feed_dict_train)
        _t_bfgs = time.clock() - _t_bfgs
        err, mse, penn, Beta = sess.run([self.error, self.mse, self.penn, self.Beta], feed_dict=feed_dict_train)
        err_test, mse_test = sess.run([self.error, self.mse], feed_dict=feed_dict_test)
        print("ERROR:", err, "MSE:", mse, "MSE TEST:", mse_test, "PENN:", penn, "TIME:", _t_bfgs)
        print(Beta)
        return mse, mse_test, penn
    def CV(self, lams, K=5):
        D = self.D
        dist_obs = [[] for _ in range(D)]
        for i in range(self.N):
            dist_obs[self.ds[i]].append(i)
        for d in range(D):
            random.shuffle(dist_obs[d])
        res = []
        with tf.Session() as sess:
            sess.run(tf.initialize_all_variables())
            for k in range(K):
                print("\nSTEP %d/%d" % (k+1, K))
                self.xs_train, self.ys_train, self.ds_train = [], [], []
                self.xs_test, self.ys_test, self.ds_test = [], [], []
                for d in range(D):
                    step = len(dist_obs[d])//K
                    s, t = k*step, (k+1)*step
                    train = dist_obs[d][:s] + dist_obs[d][t:]
                    test = dist_obs[d][s:t]
                    self.xs_train += [self.xs[i] for i in train]
                    self.ys_train += [self.ys[i] for i in train]
                    self.ds_train += [self.ds[i] for i in train]
                    self.xs_test += [self.xs[i] for i in test]
                    self.ys_test += [self.ys[i] for i in test]
                    self.ds_test += [self.ds[i] for i in test]
                for lam in lams:
                    log_lam = round(math.log(lam)/math.log(2))
                    print("\nLAMBDA:", log_lam)
                    mse_train, mse_test, penn = self.train(sess, lam)
                    res.append((log_lam, k, mse_train, mse_test, penn))
                    with open('eish.p', 'wb') as f:
                        pickle.dump(res, f)

def main():
    xs, ys, ds, R, C, graph = pickle.load(open('data_presi_primera.p', 'rb'))
    lams = [2**k for k in range(-10,11)]
    ei = EISH(xs, ys, ds, R, C, graph)
    ei.CV(lams, K=5)

def main2():
    xs, ys, ds, R, C, graph = pickle.load(open('data_presi_primera.p', 'rb'))
    ei = EISH(xs, ys, ds, R, C, graph)
    lam = 2**(-3)
    with tf.Session() as sess:
        sess.run(tf.initialize_all_variables())
        sess.run(ei.lam.assign(lam))
        ei.optimizer.minimize(session=sess)
        Beta = sess.run(ei.Beta)
        with open('beta.p', 'wb') as f:
            pickle.dump(Beta, f)
        print(Beta)
        W = ei.gammas
        Wr = tf.reshape(W, [-1, C-1]) # [_, C-1]
        zeros = tf.zeros([tf.shape(Wr)[0], 1], dtype=tf.float64) # [_, 1]
        soft = tf.nn.softmax(tf.concat(1, [Wr, zeros])) # [_, C]
        soft = tf.reshape(soft, [-1, R, C]) # [_, R, C]
        Betas = sess.run(soft)
        with open('betas.p', 'wb') as f:
            pickle.dump(Betas, f)

main()
